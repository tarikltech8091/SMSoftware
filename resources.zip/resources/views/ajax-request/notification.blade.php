<a aria-expanded="false" data-toggle="dropdown" class="dropdown-toggle" href="#"><i class="fa fa-envelope"></i><span class="badge">{{rand(1,100)}}</span></a>					
	<ul class="dropdown-menu">
		<li>
			<div class="notification_header">
				<h3>You have 3 new messages</h3>
			</div>
		</li>
		<li><a href="#">
		   <div class="user_img"><img alt="" src="images/1.png"></div>
		   <div class="notification_desc">
			<p>Lorem ipsum dolor sit amet</p>
			<p><span>1 hour ago</span></p>
			</div>
		   <div class="clearfix"></div>	
		 </a></li>
		 <li class="odd"><a href="#">
			<div class="user_img"><img alt="" src="images/1.png"></div>
		   <div class="notification_desc">
			<p>Lorem ipsum dolor sit amet </p>
			<p><span>1 hour ago</span></p>
			</div>
		  <div class="clearfix"></div>	
		 </a></li>
		<li><a href="#">
		   <div class="user_img"><img alt="" src="images/1.png"></div>
		   <div class="notification_desc">
			<p>Lorem ipsum dolor sit amet </p>
			<p><span>1 hour ago</span></p>
			</div>
		   <div class="clearfix"></div>	
		</a></li>
		<li>
			<div class="notification_bottom">
				<a href="#">See all messages</a>
			</div> 
		</li>
	</ul>