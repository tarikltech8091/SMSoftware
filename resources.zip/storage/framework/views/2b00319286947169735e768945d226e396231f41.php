<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layout.bradecrumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="row page_row">
	
	<div class="col-md-9">
		<div class="panel panel-info">
			<div class="panel-heading">
				Assigned Courses For <?php echo e(isset($univ_academic_calender) ? $univ_academic_calender->semester_title.' '.$univ_academic_calender->academic_calender_year : ''); ?>


			</div>

			<div class="panel-body">
				<table class="table table-bordered table-hover">
					<thead >
						<tr>
							<th>SL</th>
							<th>Course Title</th>
							<th>Course Code</th>
							<th>Class Teacher</th>
							<th>Program</th>
							<th>Level</th>
							<th>Term</th>
							<th>Semester</th>
							<th>Year</th>
						</tr>
					</thead>


					<tbody>
						<?php if(!empty($faculty_assingned_course)): ?>
						<?php foreach($faculty_assingned_course as $key => $list): ?>
						<tr>
							<td><?php echo e($key+1); ?></td>
							<td><?php echo e($list->assigned_course_title); ?></td>
							<td><?php echo e($list->assigned_course_id); ?></td>
							<td>
								<?php
								$class_teacher=\DB::table('program_coordinator_assigned')
								->where('coordinator_program',$list->assigned_course_program)
								->where('program_coordinator_semester',$list->assigned_course_semester)
								->where('program_coordinator_year',$list->assigned_course_year)
								->where('program_coordinator_level',$list->assigned_course_level)
								->where('program_coordinator_term',$list->assigned_course_term)
								->leftjoin('faculty_basic','faculty_basic.faculty_id','=','program_coordinator_assigned.coordinator_faculty_id')
								->first();

								?>
								<?php echo e(isset($class_teacher) ? $class_teacher->first_name.' '.$class_teacher->middle_name.' '.$class_teacher->last_name : ''); ?>

							</td>
							<td><?php echo e($list->program_title); ?></td>
							<td><?php echo e($list->assigned_course_level); ?></td>
							<td><?php echo e($list->assigned_course_term); ?></td>
							<td><?php echo e($list->semester_title); ?></td>
							<td><?php echo e($list->assigned_course_year); ?></td>

						</tr>
						<?php endforeach; ?>
						<?php endif; ?>
					</tbody>


				</table>
				

			</div><!--/info body-->
		</div>
	</div>
	<!--sidebar widget-->
	<div class="col-md-3 schedule">
		<?php echo $__env->make('pages.faculty.faculty-notice', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</div>
	<!--/sidebar widget-->
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>