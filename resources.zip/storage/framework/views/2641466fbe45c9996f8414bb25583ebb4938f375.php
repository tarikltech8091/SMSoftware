<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layout.bradecrumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--error message*******************************************-->
<div class="row page_row">
	<div class="col-md-12">
		<?php if($errors->count() > 0 ): ?>

		<div class="alert alert-danger">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<h6>The following errors have occurred:</h6>
			<ul>
				<?php foreach( $errors->all() as $message ): ?>
				<li><?php echo e($message); ?></li>
				<?php endforeach; ?>
			</ul>
		</div>
		<?php endif; ?>

		<?php if(Session::has('message')): ?>
		<div class="alert alert-success" role="alert">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<?php echo e(Session::get('message')); ?>

		</div> 
		<?php endif; ?>

		<?php if(Session::has('accounts_applicant_message')): ?>
		<div class="alert alert-success" role="alert">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			Message successfully sent to <b><?php echo e(Session::get('accounts_applicant_message')); ?></b>
		</div> 
		<?php endif; ?>

		<?php if(Session::has('errormessage')): ?>
		<div class="alert alert-danger" role="alert">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<?php echo e(Session::get('errormessage')); ?>

		</div>
		<?php endif; ?>

	</div>
</div>
<!--end of error message*************************************-->


<div class="row page_row">
	<div class="col-md-12 ">
		<div class="panel panel-body padding_0 sorting_form"><!--header inline form-->
			<?php 
			$program_list =\App\Applicant::ProgramList();

			?>
			<div class="form-group col-md-4">
				<label for="Program">Program</label>
				<select class="form-control program" name="program" >
					<option value="0">All</option>
					<?php if(!empty($program_list)): ?>
					<?php foreach($program_list as $key => $list): ?>
					<?php if(isset($program)): ?>
					<option <?php echo e(($program==$list->program_id) ? 'selected':''); ?> value="<?php echo e($list->program_id); ?>"><?php echo e($list->program_title); ?></option>
					<?php else: ?>
					<option value="<?php echo e($list->program_id); ?>"><?php echo e($list->program_title); ?></option>
					<?php endif; ?>
					
					<?php endforeach; ?>
					<?php endif; ?>
				</select>
			</div>
			<div class="form-group col-md-4">
				<label for="Semester">Trimester</label>
				<?php
				$semester_list=\DB::table('univ_semester')->get();
				?>
				<select class="form-control semester" name="semester" >
					<option value="0">All</option>
					<?php if(!empty($semester_list)): ?>
					<?php foreach($semester_list as $key => $list): ?>
					<option <?php echo e((isset($semester) && ($semester==$list->semester_code)) ? 'selected':''); ?> value="<?php echo e($list->semester_code); ?>"><?php echo e($list->semester_title); ?></option>
					<?php endforeach; ?>
					<?php endif; ?>
				</select>
			</div>
			<div class="form-group col-md-3">
				<label for="AcademicYear">Academic Year</label>
				<select class="form-control academic_year" name="academic_year" >
					<option value="0">All</option>
					<option <?php echo e((isset($academic_year) && ($academic_year==date('Y',strtotime('-1 year')))) ? 'selected':''); ?>  value="<?php echo e(date("Y",strtotime("-1 year"))); ?>"><?php echo e(date("Y",strtotime("-1 year"))); ?></option>
					<option <?php echo e((isset($academic_year) && ($academic_year==date('Y'))) ? 'selected':''); ?>  value="<?php echo e(date('Y')); ?>"><?php echo e(date('Y')); ?></option>
					<option <?php echo e((isset($academic_year) && ($academic_year==date('Y',strtotime('+1 year')))) ? 'selected':''); ?> value="<?php echo e(date("Y",strtotime("+1 year"))); ?>"><?php echo e(date("Y",strtotime("+1 year"))); ?></option>
				</select>
			</div>
			
			<div class="form-group col-md-1" style="margin-top:20px;">
				<button class="btn btn-danger applicant_payment_search" data-toggle="tooltip" title="Search Applicants By Program,Trimester,Year">Serach</button>
			</div>
		</div><!--/header inline form-->
	</div>
	
	<div class="col-md-12 applicant_payment_table">

		<div class="panel panel-body">
			<table class="table table-striped table-bordered table-hover">
				<thead>
					<tr>
						<th>SL</th>
						<th>Applicant ID</th>
						<th>Applicant Name</th>
						<th>Program</th>
						<th>Trimester</th>
						<th>Academic Year</th>
						<th>Applied Date</th>
						<th>Payment Slip</th>
						<th>Payment Amount</th>
						<th>Payment Through</th>
						<th>Payment Status</th>
						<th>Action</th>
						<th>All<input type="checkbox" id="apporoved_payment_selectall" value="0" /></th>
					</tr>
				</thead>
				<tbody>
					<?php if(count($all_applicant)>0): ?>
					
					<?php foreach($all_applicant as $key => $applicant): ?>
					<tr>
						<td><?php echo e(($key+1)); ?></td>
						<td><?php echo e($applicant->applicant_serial_no); ?></td>
						<td><?php echo e($applicant->first_name); ?> <?php echo e($applicant->middle_name); ?> <?php echo e($applicant->last_name); ?></td>
						<td><?php echo e($applicant->program_code); ?></td>
						<td><?php echo e(strtoupper($applicant->semester_title)); ?></td>
						<td><?php echo e($applicant->academic_year); ?></td>
						<td><?php echo e(date('Y-m-d',strtotime($applicant->created_at))); ?></td>
						<td><?php echo e($applicant->payment_slip_no); ?></td>
						<td><?php echo e($applicant->applicant_fees_amount); ?></td>
						<td><?php echo e(strtoupper($applicant->payment_by)); ?></td>
						<td>
							<?php if($applicant->payment_status==1 || $applicant->payment_status==5): ?>
							PAID
							<?php elseif($applicant->payment_status==2): ?>
							Waiting For Approval
							<?php elseif(($applicant->payment_status==0) || ($applicant->payment_status=='')): ?>
							TO BE PAID
							<?php endif; ?>
						</td>
						<td class="text-right">
							<?php if($applicant->payment_status==2): ?>
							<button type="button" data-loading-text="Saving..." class="btn btn-info apporoved_payment_single loadingButton" autocomplete="off" data-id="<?php echo e($applicant->applicant_serial_no); ?>" data-toggle="tooltip" title="Approve Application Payment" >Approve</button>
							<?php elseif($applicant->payment_status==1 || $applicant->payment_status==5): ?>
							<span class="approved_mark"><i class="fa fa-check"></i></span>
								<?php if((\Auth::user()->user_role=='head') && ($applicant->applicant_eligiblity == 1)): ?>
								<button class="btn btn-danger apporoved_payment_undone" data-id="<?php echo e($applicant->applicant_serial_no); ?>" data-payment-by="<?php echo e($applicant->payment_by); ?>" data-toggle="tooltip" title="Undo Applicants Payment"><i class="fa fa-undo" aria-hidden="true"></i></button>
								<?php endif; ?>
							<?php endif; ?>

							<button  type="button" class="btn btn-primary accounts_message_to_applicant" data-applicant="<?php echo e($applicant->applicant_serial_no); ?>" data-message-issue="application_payment" data-toggle="modal" data-target="#message" data-toggle1="tooltip" title="Message To Applicant"><i class="fa fa-envelope-o" aria-hidden="true"></i></button>



						</td>
						<td>
							<?php if($applicant->payment_status==2): ?>

							<input type="checkbox" name="payment_approved_checkbox[]" class="apporoved_payment_group" value="<?php echo e($applicant->applicant_serial_no); ?>">
							<?php endif; ?>

						</td>
					</tr>

					<?php endforeach; ?>
					<tr>
						<td colspan="13">
							<button type="button" data-loading-text="Saving..." class="btn btn-primary pull-right apporoved_payment_submit loadingButton" autocomplete="off" data-nexturl="<?php echo e($all_applicant->nextPageUrl()); ?>"  data-toggle="tooltip" title="Save All and Go Next Page">Save & Next</button>
						</td>
					</tr>
					<?php else: ?>
					<tr class="text-center">
						<td colspan="13">
							<div class="alert alert-success">
								<center>No Data Available !</center>
							</div>
						</td>
					</tr>

					<?php endif; ?>
				</tbody>		
			</table>
			<?php echo e(isset($pagination) ? $pagination:""); ?>

		</div>
		<input type="hidden" name="current_page_url" class="current_page_url" value="<?php echo e(\Request::fullUrl()); ?>">
		<input type="hidden" name="site_url" class="site_url" value="<?php echo e(url('/')); ?>">
	</div>
</div>



<!-- message modal -->
<div class="modal fade" id="message" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
	<div class="modal-dialog modal-md" role="document">
		<div class="write_message_to"></div>
	</div>
</div>
<!-- message modal end-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>