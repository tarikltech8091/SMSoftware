<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layout.bradecrumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="page_row row"><!--message-->
	<div class="col-md-12">
		<!--error message*******************************************-->
		<?php if($errors->count() > 0 ): ?>

		<div class="alert alert-danger">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<h6>The following errors have occurred:</h6>
			<ul>
				<?php foreach( $errors->all() as $message ): ?>
				<li><?php echo e($message); ?></li>
				<?php endforeach; ?>
			</ul>
		</div>
		<?php endif; ?>
		
		<?php if(Session::has('message')): ?>
		<div class="alert alert-success" role="alert">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<?php echo e(Session::get('message')); ?>

		</div> 
		<?php endif; ?>

		<?php if(Session::has('errormessage')): ?>
		<div class="alert alert-danger" role="alert">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<?php echo e(Session::get('errormessage')); ?>

		</div>
		<?php endif; ?>
		<!--*******************************End of error message*************************************-->
	</div>
</div><!--/message-->


<div class="row page_row">

	<div class="col-md-9">
		<div class="panel panel-info">
			<div class="panel-heading">Payment Ledger
				
			</div>
			<div class="panel-body"><!--info body-->
				<div class="student_payment">
					<div class="col-md-4">
						<table class="table table-bordered">
							<thead>
								<tr>
									<th>Name</th>
									<th><?php echo e(isset($student_info->first_name) ? $student_info->first_name : ''); ?> <?php echo e(isset($student_info->middle_name) ? $student_info->middle_name : ''); ?> <?php echo e(isset($student_info->last_name) ? $student_info->last_name : ''); ?></th>
								</tr>
								<tr>
									<th>ID</th>
									<th><?php echo e(isset($student_info->student_serial_no) ? $student_info->student_serial_no : ''); ?></th>
								</tr>
								<tr>
									<th>Program</th>
									<th><?php echo e(isset($student_info->program_code) ? $student_info->program_code : ''); ?></th>
								</tr>
							</thead>
						</table>

					</div>

					<div class="col-md-4">
						<center><h2>Student Ledger</h2></center>
						<select name="semester" class="form-control" id="student_payment_history_search">
							<option value="all">ALL</option>
							<?php if(!empty($univ_academic_calender)): ?>
							<?php foreach($univ_academic_calender as $key => $list): ?>
							<option value="<?php echo e($list->semester_code.'.'.$list->academic_calender_year); ?>"><?php echo e($list->semester_title); ?> <?php echo e($list->academic_calender_year); ?></option>
							<?php endforeach; ?>
							<?php endif; ?>
						</select>
					</div>

					<div class="col-md-4 right_side pull-right">
						<table class="table table-bordered">
							<thead>
								<tr>
									<th>Total Receivable</th>
									<th><?php echo e(isset($total_payment_receivable) ? $total_payment_receivable : ''); ?> Tk</th>
								</tr>
								<tr>
									<th>Total Paid</th>
									<th><?php echo e(isset($total_payment_paid) ? $total_payment_paid : ''); ?> Tk</th>
								</tr>
								<tr>
									<th>Total Due</th>
									<th><?php echo e(isset($total_payment_due) ? $total_payment_due : ''); ?> Tk</th>
								</tr>
							</thead>
						</table>
					</div>
				</div>

				<div id="payment_history" class="cursor" style="margin-top:20px;">
					

					<div class="col-md-12" style="height: 500px; overflow: auto; padding: 5px">
						<table class="table table-striped table-bordered table-hover table-condensed" style="background-color:#EDEDED" >
							<thead>
								<tr>
									<th colspan="9"><center>Payment Ledger: ALL</center></th>
								</tr>
								<tr>
									<th>Tran Date</th>
									<th>Semester</th>
									<th>Year</th>
									<th>Collected By</th>
									<th>Fee Type</th>
									<th>Payment Receivable</th>
									<th>Payment Paid</th>
									<th>Payment Other</th>
									<th>Total Amount</th>
								</tr>
							</thead>
							<tbody>
								<?php if(!empty($student_payment_transaction_detail)): ?>
								<?php
								$total_receivable=0;
								$total_paid=0;
								$total_other=0;
								$total_amount=0;
								?>
								<?php foreach($student_payment_transaction_detail as $key => $student_payment_transaction): ?>

								<tr>
									<td><?php echo e(date("Y-m-d",strtotime($student_payment_transaction->created_at))); ?></td>
									<td><?php echo e($student_payment_transaction->semester_title); ?></td>
									<td><?php echo e($student_payment_transaction->payment_year); ?></td>
									<td>
										<?php echo e($student_payment_transaction->payment_receive_type); ?>

									</td>
									<td>
										<!-- <?php echo e(isset($student_payment_transaction->fee_category_name) ? $student_payment_transaction->fee_category_name : 'Waiver'); ?> -->

										<?php
										$fee_category=DB::table('fee_category')->where('fee_category_name_slug',$student_payment_transaction->payment_transaction_fee_type)->first();
										?>
										<?php if(!empty($fee_category)): ?>
											<?php echo e($fee_category->fee_category_name); ?>

										<?php elseif($student_payment_transaction->payment_transaction_fee_type=='other_fees'): ?>
											Other Fees
										<?php else: ?>

											<?php if(($student_payment_transaction->payment_transaction_fee_type) == 'Waiver'): ?>
											<?php $waiver_info=\DB::table('waivers')->where('waiver_name_slug', $student_payment_transaction->waiver_type)->first(); ?>
												<?php echo e($student_payment_transaction->payment_transaction_fee_type); ?> (<?php echo e(isset($waiver_info)? $waiver_info->waiver_name :''); ?>)
											<?php else: ?>
												<?php echo e($student_payment_transaction->payment_transaction_fee_type); ?>

											<?php endif; ?>
										<?php endif; ?>
									</td>
									<td>
										<?php if(($student_payment_transaction->payment_transaction_fee_type == 'tution_fee') && ($student_payment_transaction->payment_receivable !=0)): ?>
											<span data-toggle="tooltip" title="<?php echo e($student_payment_transaction->payment_details); ?>"><?php echo e($student_payment_transaction->payment_receivable); ?></span>
										<?php else: ?>
											<?php echo e($student_payment_transaction->payment_receivable); ?>

										<?php endif; ?>
									</td>
									<td><?php echo e($student_payment_transaction->payment_paid); ?></td>
									<td><?php echo e($student_payment_transaction->payment_others); ?></td>
									<td><?php echo e($student_payment_transaction->payment_amounts); ?></td>
								</tr>

								<?php
								$total_receivable=$total_receivable+$student_payment_transaction->payment_receivable;
								$total_paid=$total_paid+$student_payment_transaction->payment_paid;
								$total_other=$total_other+$student_payment_transaction->payment_others;
								$total_amount=$total_amount+$student_payment_transaction->payment_amounts;
								?>

								<?php endforeach; ?>
								<tr>
									<th colspan="5"><center>Total Transaction</center></th>
									<th><?php echo e($total_receivable); ?></th>
									<th><?php echo e($total_paid); ?></th>
									<th><?php echo e($total_other); ?></th>
									<th><?php echo e($total_amount); ?></th>
								</tr>
								<?php endif; ?>
							</tbody>
						</table>
					</div>

				</div>


			</div><!--/info body-->
		</div>
	</div>
	<!--sidebar widget-->
	<div class="col-md-3">
		<?php echo $__env->make('pages.student.student-widget', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</div>
	<!--/sidebar widget-->	
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>