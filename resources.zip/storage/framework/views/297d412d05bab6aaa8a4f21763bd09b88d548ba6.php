<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layout.bradecrumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--error message*******************************************-->
<div class="row page_row">

	<div class="col-md-12">
		<?php if($errors->count() > 0 ): ?>

		<div class="alert alert-danger">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<h6>The following errors have occurred:</h6>
			<ul>
				<?php foreach( $errors->all() as $message ): ?>
				<li><?php echo e($message); ?></li>
				<?php endforeach; ?>
			</ul>
		</div>
		<?php endif; ?>

		<?php if(Session::has('message')): ?>
		<div class="alert alert-success" role="alert">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<?php echo e(Session::get('message')); ?>

		</div> 
		<?php endif; ?>

		<?php if(Session::has('errormessage')): ?>
		<div class="alert alert-danger" role="alert">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<?php echo e(Session::get('errormessage')); ?>

		</div>
		<?php endif; ?>

	</div>
</div>
<!--end of error message*************************************-->


<div class="row page_row">
	<div class="col-md-12  profile_tab">
		<div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
			
			<ul id="myTab" class="nav nav-tabs" role="tablist">

				<li role="presentation" class="<?php echo e($tab=='student_info' ? 'active' :''); ?>"><a href="#student_info" role="tab" id="student_info-tab" data-toggle="tab" aria-controls="student_info"><i class="fa fa-info-circle" aria-hidden="true"></i>Student Info</a></li>
				<li role="presentation" class="<?php echo e($tab=='accepted_course' ? 'active' :''); ?>"><a href="#accepted_course" role="tab" id="accepted_course-tab" data-toggle="tab" aria-controls="accepted_course"><i class="fa fa-book"></i>Accepted Course</a></li>

			</ul>


			<div id="myTabContent" class="tab-content"><!--main tab content-->
				<div role="tabpanel"  id="student_info"  class="tab-pane fade <?php echo e($tab=='student_info' ? 'in active' :''); ?>" aria-labelledby="student_info-tab">
					<div class="row">
						<div class="col-md-10">
							<div class="panel panel-body page_row">
								<div class="alert alert-info">
									<h3>Student Information</h3><br>

									<form action="<?php echo e(url('/register/existing/student/submit')); ?>" method="post" enctype="multipart/form-data">
										<div class="row"><!--basic block form -->
											<div class="col-md-12">
												<div class="row">
													<div class="form-group col-md-4">
														<label for="First Name">First Name<span class="required-sign">*</span></label>
														<input type="text" class="form-control uppercase_name" name="first_name" placeholder="First Name" value="<?php echo e(old('first_name')); ?>">
													</div>
													<div class="form-group col-md-4">
														<label for="Middle Name">Middle Name</label>
														<input type="text" class="form-control uppercase_name" name="middle_name" placeholder="Middle Name" value="<?php echo e(old('middle_name')); ?>">
													</div>
													<div class="form-group col-md-4">
														<label for="Last Name">Last Name<span class="required-sign">*</span></label>
														<input type="text" class="form-control uppercase_name" name="last_name" placeholder="Last Name" value="<?php echo e(old('last_name')); ?>">
													</div>
												</div>

												<?php 
												$program_list =\App\Register::ProgramList();
												?>
												<div class="row">
													<div class="form-group col-md-4">
														<label for="Program">Program<span class="required-sign">*</span></label>
														<select class="form-control" name="program">
															<?php if(!empty($program_list)): ?>
															<?php foreach($program_list as $key => $list): ?>
															<option <?php echo e((old('program')== $list->program_id) ? "selected" :''); ?> value="<?php echo e($list->program_id); ?>"><?php echo e($list->program_title); ?></option>
															<?php endforeach; ?>
															<?php endif; ?>
														</select> 
													</div>
													<div class="form-group col-md-4">
														<label for="Semester">Trimester<span class="required-sign">*</span></label>
														<?php
														$semester_list=\DB::table('univ_semester')->get();
														?>
														<select class="form-control" name="semester">
															<?php if(!empty($semester_list)): ?>
															<?php foreach($semester_list as $key => $semester): ?>
															<option <?php echo e((old('semester')== $semester->semester_code) ? "selected" :''); ?> value="<?php echo e($semester->semester_code); ?>"><?php echo e($semester->semester_title); ?></option>
															<?php endforeach; ?>
															<?php endif; ?>
														</select>
													</div>

													<div class="form-group col-md-4">
														<label for="AcademicYear">Academic Year<span class="required-sign">*</span></label>
														<select class="form-control" name="academic_year">
															<option <?php echo e((old('academic_year')) ? 'selected':''); ?>  value="<?php echo e(date('Y')); ?>"><?php echo e(date('Y')); ?></option>
															<option <?php echo e((old('academic_year')) ? 'selected':''); ?> value="<?php echo e(date("Y",strtotime('-1 year'))); ?>"><?php echo e(date('Y',strtotime("-1 year"))); ?></option>
															<option <?php echo e((old('academic_year')) ? 'selected':''); ?> value="<?php echo e(date("Y",strtotime('-2 year'))); ?>"><?php echo e(date('Y',strtotime("-2 year"))); ?></option>
															<option <?php echo e((old('academic_year')) ? 'selected':''); ?> value="<?php echo e(date("Y",strtotime('-3 year'))); ?>"><?php echo e(date('Y',strtotime("-3 year"))); ?></option>
															<option <?php echo e((old('academic_year')) ? 'selected':''); ?> value="<?php echo e(date("Y",strtotime('-4 year'))); ?>"><?php echo e(date('Y',strtotime("-4 year"))); ?></option>
															<option <?php echo e((old('academic_year')) ? 'selected':''); ?> value="<?php echo e(date("Y",strtotime('-5 year'))); ?>"><?php echo e(date('Y',strtotime("-5 year"))); ?></option>
														</select>
													</div>
												</div>
											</div>

										</div><!-- /basic block form -->

										<hr style="border-width: 1px;">
										<br>
										<div class="row"><!--academic form-->
											<div class="col-md-12">
												<div class="form-group col-md-2">
													<label >Exam Type<span class="required-sign">*</span></label>
													<select class="form-control" name="ssc_exam_type" >
														<option  <?php echo e((old('ssc_exam_type')== "SSC") ? "selected" :''); ?> value="SSC">SSC</option>
														<option  <?php echo e((old('ssc_exam_type')== "olevel") ? "selected" :''); ?> value="olevel">O level</option>
													</select>
												</div>
												<div class="form-group col-md-2">
													<label >Group<span class="required-sign">*</span></label>
													<select class="form-control" name="ssc_group_name">
														<option <?php echo e((old('ssc_group_name')== "science") ? "selected" :''); ?> value="science">Science</option>
														<option <?php echo e((old('ssc_group_name')== "arts") ? "selected" :''); ?> value="arts">Arts</option>
														<option <?php echo e((old('ssc_group_name')== "commerce") ? "selected" :''); ?> value="commerce">Commerce</option>
													</select>
												</div>

												<div class="form-group col-md-2">
													<label >Roll Number<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="ssc_roll_number"  value="<?php echo e(old('ssc_roll_number')); ?>" >
												</div>
												<div class="form-group col-md-2">
													<label >Board<span class="required-sign">*</span></label>
													<select  class="form-control" name="ssc_board_name">
														<option  <?php echo e((old('ssc_board_name')== 0) ? "selected" :''); ?> value="0">Select One</option>
														<option  <?php echo e((old('ssc_board_name')== "barisal") ? "selected" :''); ?> value="barisal">Barisal</option>
														<option  <?php echo e((old('ssc_board_name')== "chittagong") ? "selected" :''); ?> value="chittagong">Chittagong</option>
														<option  <?php echo e((old('ssc_board_name')== "comilla") ? "selected" :''); ?> value="comilla">Comilla</option>
														<option  <?php echo e((old('ssc_board_name')== "dhaka") ? "selected" :''); ?> value="dhaka">Dhaka</option>
														<option  <?php echo e((old('ssc_board_name')== "dinajpur") ? "selected" :''); ?> value="dinajpur">Dinajpur</option>
														<option  <?php echo e((old('ssc_board_name')== "jessore") ? "selected" :''); ?> value="jessore">Jessore</option>
														<option  <?php echo e((old('ssc_board_name')== "rajshahi") ? "selected" :''); ?> value="rajshahi">Rajshahi</option>
														<option  <?php echo e((old('ssc_board_name')== "sylhet") ? "selected" :''); ?> value="sylhet">Sylhet</option>
														<option  <?php echo e((old('ssc_board_name')== "madrasah") ? "selected" :''); ?> value="madrasah">Madrasah</option>
														<option  <?php echo e((old('ssc_board_name')== "technical") ? "selected" :''); ?> value="technical">Technical</option>
														<option  <?php echo e((old('ssc_board_name')== "dibs") ? "selected" :''); ?> value="dibs">DIBS(Dhaka)</option>
													</select>
												</div>
												<div class="form-group col-md-2">
													<label >Passing Year<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="ssc_olevel_year" placeholder="Year" value="<?php echo e(old('ssc_olevel_year')); ?>" >
												</div>
												<div class="form-group col-md-2">
													<label class="control-label ">Total GPA<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="total_ssc_olevel_gpa" placeholder="Total GPA" value="<?php echo e(old('total_ssc_olevel_gpa')); ?>" >
												</div>
											</div>


											<hr style="border-width: 1px;">
											<br>

											<div class="col-md-12">
												<div class="form-group col-md-2">
													<label >Exam Type<span class="required-sign">*</span></label>
													<select class="form-control" name="hsc_exam_type" >
														<option  <?php echo e((old('hsc_exam_type')== "HSC") ? "selected" :''); ?> value="HSC">HSC</option>
														<option  <?php echo e((old('hsc_exam_type')== "Alevel") ? "selected" :''); ?> value="alevel">A level</option>
													</select>
												</div>
												<div class="form-group col-md-2">
													<label >Group<span class="required-sign">*</span></label>
													<select class="form-control" name="hsc_group_name">
														<option <?php echo e((old('hsc_group_name')== "science") ? "selected" :''); ?> value="science">Science</option>
														<option <?php echo e((old('hsc_group_name')== "arts") ? "selected" :''); ?> value="arts">Arts</option>
														<option <?php echo e((old('hsc_group_name')== "commerce") ? "selected" :''); ?> value="commerce">Commerce</option>
													</select>
												</div>

												<div class="form-group col-md-2">
													<label >Roll Number<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="hsc_roll_number" value="<?php echo e(old('hsc_roll_number')); ?>">
												</div>
												<div class="form-group col-md-2">
													<label >Board<span class="required-sign">*</span></label>
													<select  class="form-control" name="hsc_board_name">
														<option  <?php echo e((old('hsc_board_name')== 0) ? "selected" :''); ?> value="0"selected>Select One</option>
														<option  <?php echo e((old('hsc_board_name')== "barisal") ? "selected" :''); ?> value="barisal">Barisal</option>
														<option  <?php echo e((old('hsc_board_name')== "chittagong") ? "selected" :''); ?> value="chittagong">Chittagong</option>
														<option  <?php echo e((old('hsc_board_name')== "comilla") ? "selected" :''); ?> value="comilla">Comilla</option>
														<option  <?php echo e((old('hsc_board_name')== "dhaka") ? "selected" :''); ?> value="dhaka">Dhaka</option>
														<option  <?php echo e((old('hsc_board_name')== "dinajpur") ? "selected" :''); ?> value="dinajpur">Dinajpur</option>
														<option  <?php echo e((old('hsc_board_name')== "jessore") ? "selected" :''); ?> value="jessore">Jessore</option>
														<option  <?php echo e((old('hsc_board_name')== "rajshahi") ? "selected" :''); ?> value="rajshahi">Rajshahi</option>
														<option  <?php echo e((old('hsc_board_name')== "sylhet") ? "selected" :''); ?> value="sylhet">Sylhet</option>
														<option  <?php echo e((old('hsc_board_name')== "madrasah") ? "selected" :''); ?> value="madrasah">Madrasah</option>
														<option  <?php echo e((old('hsc_board_name')== "technical") ? "selected" :''); ?> value="technical">Technical</option>
														<option  <?php echo e((old('hsc_board_name')== "dibs") ? "selected" :''); ?> value="dibs">DIBS(Dhaka)</option>
													</select>
												</div>
												<div class="form-group col-md-2">
													<label >Passing Year<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="hsc_olevel_year" placeholder="Year" value="<?php echo e(old('hsc_olevel_year')); ?>">
												</div>
												<div class="form-group col-md-2">
													<label class="control-label ">Total GPA<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="total_hsc_olevel_gpa" placeholder="Total GPA" value="<?php echo e(old('total_hsc_olevel_gpa')); ?>" >
												</div>
											</div>

										</div><!--/academic form-->
										<hr style="border-width: 1px;">
										<br>

										<div class="row"><!--personal form-->

											<div class="col-md-12">


												<div class="form-group col-md-3">
													<label for="Roll No">Student Batch<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="batch" placeholder="Batch" value="<?php echo e(old('batch')); ?>" >	
												</div>

												<div class="form-group col-md-3">
													<label for="Roll No">University Roll No<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="univ_roll_no" placeholder="University Roll No" value="<?php echo e(old('univ_roll_no')); ?>" >	
												</div>

												<div class="form-group col-md-3">
													<label for="City">Birth Place: City<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="place_of_birth" placeholder="Place Of Birth" value="<?php echo e(old('place_of_birth')); ?>" >	
												</div>

												<div class="form-group col-md-3">
													<label >Nationality<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="nationality" placeholder="Nationality" value="<?php echo e(old('nationality')); ?>" >
												</div>

											</div>
											<div class="col-md-12">

												<div class="form-group col-md-3">
													<label for="Gender">Gender<span class="required-sign">*</span></label>
													<select class="form-control" name="gender">
														<option <?php echo e((old('gender')== "male") ? "selected" :''); ?> value="male">Male</option>
														<option <?php echo e((old('gender')== "female") ? "selected" :''); ?> value="female">Female</option>
													</select>
												</div>


												<div class="form-group col-md-3">
													<div class="control-group">
														<label class="control-label">Date of Birth <span class="required-sign">*</span></label>
														<div class="input-group date date_of col-md-12" data-date="" data-count="1" data-date-format="yyyy-mm-dd" data-link-field="date_of_birth" data-link-format="yyyy-mm-dd">
															<input class="form-control" name="date_of_birth"  size="16" type="text" value="" readonly>
															<span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
															<span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
														</div>
													</div>
												</div>

												<div class="form-group col-md-3">
													<label >Blood Group</label>
													<select class="form-control" name="blood_group">
														<option <?php echo e((old('blood_group')== "") ? "selected" :''); ?>  value="">Select Blood Group</option>
														<option <?php echo e((old('blood_group')== "A+") ? "selected" :''); ?>  value="A+">A (+)</option>
														<option <?php echo e((old('blood_group')== "A-") ? "selected" :''); ?> value="A-">A (-)</option>
														<option <?php echo e((old('blood_group')== "AB+") ? "selected" :''); ?> value="AB+">AB (+)</option>
														<option <?php echo e((old('blood_group')== "AB-") ? "selected" :''); ?> value="AB-">AB (-)</option>
														<option <?php echo e((old('blood_group')== "O+") ? "selected" :''); ?>  value="O+">O (+)</option>
														<option <?php echo e((old('blood_group')== "O-") ? "selected" :''); ?> value="O-">O (-)</option>
														<option <?php echo e((old('blood_group')== "B+") ? "selected" :''); ?> value="B+">B (+)</option>
														<option <?php echo e((old('blood_group')== "B-") ? "selected" :''); ?> value="B-">B (-)</option>
													</select>
												</div>
												<div class="form-group col-md-3">
													<label >Marital Status</label>
													<select class="form-control" name="marital_status">
														<option <?php echo e((old('marital_status')== "single") ? "selected" :''); ?> value="single">Single</option>
														<option <?php echo e((old('marital_status')== "married") ? "selected" :''); ?> value="married">Married</option>
														<option <?php echo e((old('marital_status')== "other") ? "selected" :''); ?> value="other">Other</option>
													</select>
												</div>
											</div>


											<div class="col-md-12">
												<div class="form-group col-md-3">
													<label for="Religion">Religion<span class="required-sign">*</span></label>
													<select class="form-control" name="religion">
														<option <?php echo e((old('religion')== "") ? "selected" :''); ?>  value="">Select Religion</option>
														<option <?php echo e((old('religion')== "islam") ? "selected" :''); ?>  value="islam">Islam</option>
														<option <?php echo e((old('religion')== "christianity") ? "selected" :''); ?> value="christianity">Christianity</option>
														<option <?php echo e((old('religion')== "hinduism") ? "selected" :''); ?> value="hinduism">Hinduism</option>
														<option <?php echo e((old('religion')== "buddhism") ? "selected" :''); ?> value="buddhism">Buddhism</option>
														<option <?php echo e((old('religion')== "others") ? "selected" :''); ?> value="others">Others</option>

													</select> 	
												</div>
												<div class="form-group col-md-3">
													<label for="Email">Email<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="email" placeholder="abcd@gmail.com" value="<?php echo e(old('email')); ?>">	
												</div>
												<div class="form-group col-md-3">
													<label for="Phone">Phone</label>
													<input type="text" class="form-control" name="phone" placeholder="9300000" value="<?php echo e(old('phone')); ?>" >	
												</div>
												<div class="form-group col-md-3">
													<label >Mobile<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="mobile" placeholder="01000000000" value="<?php echo e(old('mobile')); ?>" >
												</div>
												<input type="hidden" name="image_url" id="image_url">
											</div>

										</div><!--/personal form-->

										<hr style="border-width: 1px;">
										<br>
										<div class="row"><!--contact and address form-->
											<div class="col-md-12">
												<div class="form-group col-md-3">
													<label >Present Address<span class="required-sign">*</span></label>
													<textarea class="form-control" name="present_address_detail" rows="1"></textarea>

												</div>
												<div class="form-group col-md-3">
													<label>Postal Code<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="present_postal_code" value="<?php echo e(old('present_postal_code')); ?>" placeholder="Postal Code" >
												</div>
												<div class="form-group col-md-3">
													<label >City<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="present_city" placeholder="City" value="<?php echo e(old('present_city')); ?>" >
												</div>
												<div class="form-group col-md-3">
													<label>Country<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="present_country" value="<?php echo e(old('present_country')); ?>" placeholder="Country" >
												</div>
											</div>
											<div class="col-md-12">
												<div class="form-group col-md-3">
													<label >Permanent Address<span class="required-sign">*</span></label>
													<textarea class="form-control" name="permanent_address_detail" rows="1" > </textarea>
												</div>
												<div class="form-group col-md-3">
													<label>Postal Code<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="permanent_postal_code" placeholder="Postal Code" value="<?php echo e(old('permanent_postal_code')); ?>" >
												</div>
												<div class="form-group col-md-3">
													<label >City<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="permanent_city" placeholder="City" value="<?php echo e(old('permanent_city')); ?>" >
												</div>
												<div class="form-group col-md-3">
													<label>Country<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="permanent_country" placeholder="Country" value="<?php echo e(old('permanent_country')); ?>" >
												</div>
											</div>


											<div class="col-md-12">
												<div class="form-group col-md-3">
													<label >Father's Name<span class="required-sign">*</span></label>
													<input type="text" class="form-control uppercase_name" name="father_name" placeholder="Fathers Name" value="<?php echo e(old('father_name')); ?>" >
												</div>
												<div class="form-group col-md-3">
													<label >Father's Occupation<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="father_occupation" placeholder="Fathers Occupation" value="<?php echo e(old('father_occupation')); ?>" >
												</div>

												<div class="form-group col-md-3">
													<label>Father's Mobile<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="father_contact_mobile" placeholder="Ex:- 01722000000" value="<?php echo e(old('father_contact_mobile')); ?>" >
												</div>
												<div class="form-group col-md-3">
													<label>Father's Email</label>
													<input type="text" class="form-control" name="father_contact_email" placeholder="example@example.com" value="<?php echo e(old('father_contact_email')); ?>" >
												</div>
											</div>
											<div class="col-md-12">
												<div class="form-group col-md-3">
													<label >Mother's Name<span class="required-sign">*</span></label>
													<input type="text" class="form-control uppercase_name" name="mother_name" placeholder="Mothers Name" value="<?php echo e(old('mother_name')); ?>" >
												</div>
												<div class="form-group col-md-3">
													<label >Mother's Occupation<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="mother_occupation" placeholder="Mother's Occupation" value="<?php echo e(old('mother_occupation')); ?>" >
												</div>
												<div class="form-group col-md-3">
													<label>Mother's Mobile<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="mother_contact_mobile" placeholder="Ex:- 01000000000" value="<?php echo e(old('mother_contact_mobile')); ?>" >
												</div>
												<div class="form-group col-md-3">
													<label>Mother's Email</label>
													<input type="text" class="form-control" name="mother_contact_email" placeholder="example@example.com" value="<?php echo e(old('mother_contact_email')); ?>" >
												</div>
											</div>

											<div class="col-md-12">
												<div class="form-group col-md-3">
													<label >Local Guardian Name<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="local_guardian_name"  value="<?php echo e(old('local_guardian_name')); ?>">
												</div>
												<div class="form-group col-md-3">
													<label > Guardian Occupation<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="local_guardian_occupation" placeholder="Local Guardian Occupation" value="<?php echo e(old('local_guardian_occupation')); ?>" >
												</div>
												<div class="form-group col-md-3">
													<label> Guardian Mobile<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="local_guardian_contact_mobile" placeholder="Ex:- 01722000000" value="<?php echo e(old('local_guardian_contact_mobile')); ?>" >
												</div>
												<div class="form-group col-md-3">
													<label> Guardian Email</label>
													<input type="text" class="form-control" name="local_guardian_contact_email" placeholder="example@example.com" value="<?php echo e(old('local_guardian_contact_email')); ?>" >
												</div>
											</div>

											<div class="col-md-12">
												<div class="form-group col-md-4">
													<label>Paid Tution Fees<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="paid_tution_fees" placeholder="EX : 10000" value="<?php echo e(old('paid_tution_fees')); ?>" >								
												</div>

												<div class="form-group col-md-4">
													<label>Paid Trimester Fees<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="paid_trimester_fees" placeholder="EX : 10000" value="<?php echo e(old('paid_trimester_fees')); ?>" >								
												</div>

												<div class="form-group col-md-4">
													<label>Paid Others Fees</label>
													<input type="text" class="form-control" name="paid_others_fees" placeholder="EX : 10000" value="<?php echo e(old('paid_others_fees')); ?>" >								
												</div>

											</div>

											<div class="col-md-12">
												<div class="form-group col-md-3">
													<h4>Emergency contact:<span class="required-sign">*</span></h4>						
												</div>
												<div class="form-group col-md-6">
													<input type="radio" name="emergency_contact"  value="Father" > Father				
													<input type="radio" name="emergency_contact"  value="Mother" > Mother
													<input type="radio" name="emergency_contact"  value="Local_Guardian" checked> Local Guardian										
												</div>

												<?php
												$waiver_list=\DB::table('waivers')->get();
												?>
												<!-- 												
												<div class="form-group col-md-3">
													<label>Waiver : </label>
													<select class="form-control" name="waiver">
														<option value="">Select Waiver Type</option>
														<?php if(!empty($waiver_list)): ?>
														<?php foreach($waiver_list as $key => $list): ?>
														<option <?php echo e((old('waiver')== $list->waiver_name_slug) ? "selected" :''); ?> value="<?php echo e($list->waiver_name_slug); ?>"><?php echo e($list->waiver_name); ?></option>
														<?php endforeach; ?>
														<?php endif; ?>
													</select> 
												</div> -->

											</div>
										</div>
										<hr>
										<div class="text-right" style="margin-top:30px;">
											<div class="col-md-12">
												
												<a href="<?php echo e(\Request::url()); ?>" class="btn btn-danger">Reset</a>
												<input type="submit" class="btn btn-primary" value="Submit">
											</div>
										</div><br><br>
									</form>
								</div>	
							</div> <!-- /panel body -->
						</div>



						<div class="col-md-2" style="margin-top:10px;">
							<div class="panel panel-default">
								<div class="panel-body">
									<div id="validation-errors"></div>
									<label>Passposrt Size Photo (Colored) <span class="required-sign">*</span></label>    
									<div id="demo">
										<img  src="<?php echo e(old('image_url') ? asset(old('image_url')):asset('images/profile.png')); ?>" alt="img">
									</div>
									<div class="uploader">
										<form class="example" id="upload" role="form" enctype="multipart/form-data" method="POST" action="<?php echo e(url('/register/student/credit/transfer/image-upload')); ?>" >
											<div class="fileinputs">
												<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />

												<span class="btn btn-primary btn-file span-photo"> 
													Browse Photo<input name="image" id="image_transfer_student" noscript="true" type="file" name="photo" class="form-control btn-file-browse-photo">
													
												</span>
												
											</div>

										</form>
										<div class='image_loader'></div>
										
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>


				<div role="tabpanel"  id="accepted_course"  class="tab-pane fade <?php echo e($tab=='accepted_course' ? 'in active' :''); ?>" aria-labelledby="accepted_course-tab">


					<div class="row">
						<div class="col-md-12">
							<div class="panel panel-body padding_0">
								<?php 
								$program_list =\App\Applicant::ProgramList();
								?>
								<form method="get" action="<?php echo e(url('/register/existing/student')); ?>">

									<div class="form-group col-md-3">
										<label for="Program">Program<span class="required-sign">*</span></label>
										<select class="form-control select_program" name="program" >
											<option value="">Select Program</option>
											<?php if(!empty($program_list)): ?>
											<?php foreach($program_list as $key => $list): ?>

											<option <?php echo e((isset($_GET['program']) && ($_GET['program']==$list->program_id)) ? 'selected' : ''); ?> value="<?php echo e($list->program_id); ?>"><?php echo e($list->program_title); ?></option>

											<?php endforeach; ?>
											<?php endif; ?>
										</select>
									</div>


										<div class="form-group col-md-4">
											<label>Student Batch<span class="required-sign">*</span></label>
											<select class="form-control get_batch select_batch" name="batch" id="student_program">
												<option value="">Select Batch</option>
											</select>									
										</div>



										<div class="form-group col-md-4">
											<label>Student List<span class="required-sign">*</span></label>
											<select class="form-control get_student" name="student_no" id="student_serial_no">
												<option value="">Select Student</option>

											</select>									
										</div>

									<div class="col-md-1 margin_top_20" style="margin-top:25px;">
										<button class="btn btn-danger" data-toggle="tooltip" title="Search Courses">Serach</button>
									</div>
								</form>

							</div>
						</div>
					</div>

					<?php if(!empty($_GET['program']) && !empty($_GET['batch']) && !empty($_GET['student_no'])): ?>
					<div class="row">
						<div class="col-md-12">
							
								<?php
									$student_info=\DB::table('student_basic')->where('student_serial_no',$_GET['student_no'])->first();
									$program_info=\DB::table('univ_program')->where('program_id',$_GET['program'])->first();
								?>

								<?php if(!empty($student_info) && !empty($program_info)): ?>


									<div class="row">

											<div class="form-group col-md-3">
												<span>Program : </span><?php echo e(isset($_GET['program']) && $_GET['program'] == $program_info->program_id ? $program_info->program_code : ''); ?>

											</div>

											<div class="col-md-3">
												<span>Student Id : </span><?php echo e(isset($_GET['student_no']) && $_GET['student_no'] == $student_info->student_serial_no ? $student_info->student_serial_no  : ''); ?>

											</div>

											<div class="col-md-3">
												<span>Name: </span><?php echo e(isset($_GET['student_no']) && $_GET['student_no'] == $student_info->student_serial_no ? $student_info->first_name  : ''); ?>

											</div>

											<div class="col-md-3">
												<span>Batch : </span><?php echo e(isset($_GET['batch']) && $_GET['batch'] == $student_info->batch_no ? $student_info->batch_no : ''); ?>

											</div>
											
										<div class="col-md-12">
										<caption><strong>Instruction:</strong>Here all value is to be numeric.</caption>
										</div>

									</div>

									<table class="table table-bordered table-hover ">
										<?php if(!empty($all_theory_course)): ?>

											<thead>
												<tr>
													<th class="text-center">SL</th>
													<th class="text-center">Course Title</th>
													<th colspan="3" class="text-center">AcademicYear</th>
													<th colspan="2" class="text-center">AcademicSemester</th>
													<th class="text-center">CT-1(10%)</th>
													<th class="text-center">CT-2(10%)</th>
													<th class="text-center">CT-3(10%)</th>
													<th class="text-center">CT-4(10%)</th>
													<th class="text-center">Attendance(10%)</th>
													<th class="text-center">Participation(5%)</th>
													<th class="text-center">Presentaion(15%)</th>
													<th class="text-center">Midterm(20%)</th>
													<th class="text-center">Final(40%)</th>
													<th>Action</th>
												</tr>
											</thead>

											<tbody>
												<?php foreach($all_theory_course as $key => $course_list): ?>
												<tr>
												<form method="get" action="<?php echo e(url('/register/existing/student/marks/submit')); ?>" enctype="multipart/form-data">
												
													<td><?php echo e($key+1); ?></td>
													<td>(<?php echo e($course_list->course_code); ?>) <?php echo e($course_list->course_title); ?></td>

													<?php 
														$student_class_register_info=\DB::table('student_class_registers')
	                                                       ->where('student_tran_code',$student_info->student_tran_code)
	                                                       ->where('student_class_registers.class_course_code',$course_list->course_code)
	                                                       ->where('student_class_registers.class_result_status','1')
	                                                       ->first();

	                                                ?>

													<td colspan="3">
														<select class="form-control" id="course_year_<?php echo e($course_list->course_code); ?>" name="course_year">
															<option value="">Select Year </option>
															<?php if(!empty($univ_academic_calender)): ?>
															<?php foreach($univ_academic_calender as $key => $list): ?>
															<option  <?php echo e(isset($student_class_register_info) && !empty($student_class_register_info) && $student_class_register_info->class_year == date("Y",strtotime("-5 year")) ? 'selected' :''); ?>   value="<?php echo e(date("Y",strtotime("-5 year"))); ?>"><?php echo e(date("Y",strtotime("-5 year"))); ?></option>
															<option  <?php echo e(isset($student_class_register_info) && !empty($student_class_register_info) && $student_class_register_info->class_year == date("Y",strtotime("-4 year")) ? 'selected' :''); ?>  value="<?php echo e(date("Y",strtotime("-4 year"))); ?>"><?php echo e(date("Y",strtotime("-4 year"))); ?></option>
															<option  <?php echo e(isset($student_class_register_info) && !empty($student_class_register_info) && $student_class_register_info->class_year == date("Y",strtotime("-3 year")) ? 'selected' :''); ?>  value="<?php echo e(date("Y",strtotime("-3 year"))); ?>"><?php echo e(date("Y",strtotime("-3 year"))); ?></option>
															<option  <?php echo e(isset($student_class_register_info) && !empty($student_class_register_info) && $student_class_register_info->class_year == date("Y",strtotime("-2 year")) ? 'selected' :''); ?>   value="<?php echo e(date("Y",strtotime("-2 year"))); ?>"><?php echo e(date("Y",strtotime("-2 year"))); ?></option>
															<option  <?php echo e(isset($student_class_register_info) && !empty($student_class_register_info) && $student_class_register_info->class_year == date("Y",strtotime("-1 year")) ? 'selected' :''); ?>   value="<?php echo e(date("Y",strtotime("-1 year"))); ?>"><?php echo e(date("Y",strtotime("-1 year"))); ?></option>
															<option <?php echo e(isset($student_class_register_info) && !empty($student_class_register_info) && $student_class_register_info->class_year == date('Y') ? 'selected' :''); ?>  value="<?php echo e(date('Y')); ?>"><?php echo e(date('Y')); ?></option>
															<option <?php echo e(isset($student_class_register_info) && !empty($student_class_register_info) && $student_class_register_info->class_year == date("Y",strtotime("+1 year")) ? 'selected' :''); ?> value="<?php echo e(date("Y",strtotime("+1 year"))); ?>"><?php echo e(date("Y",strtotime("+1 year"))); ?></option>

															<?php endforeach; ?>
															<?php endif; ?>
														</select>	
													</td>
												
													<td colspan="2">
														<select class="form-control" id="course_semester_<?php echo e($course_list->course_code); ?>" name="course_semester" >
															<option value="">Select Semester</option>
															<?php if(!empty($all_semester)): ?>
															<?php foreach($all_semester as $key => $list): ?>

															<option <?php echo e(isset($student_class_register_info) && !empty($student_class_register_info) && $student_class_register_info->class_semster == $list->semester_code? 'selected' :''); ?>

															  value="<?php echo e($list->semester_code); ?>"><?php echo e($list->semester_title); ?></option>

															<?php endforeach; ?>
															<?php endif; ?>
														</select>	
													</td>

													<input type="hidden" class="form-control" id="student_serial_no_<?php echo e($course_list->course_code); ?>" name="student_serial_no" value="<?php echo e($student_info->student_serial_no); ?>" />
													<input type="hidden" class="form-control" id="course_type_<?php echo e($course_list->course_code); ?>" name="course_type" value="<?php echo e($course_list->course_type); ?>" />
													<input type="hidden" class="form-control" name="course_code" value="<?php echo e($course_list->course_code); ?>" />
													<td><input type="text" id="ct_1_<?php echo e($course_list->course_code); ?>" class="form-control" name="ct_1" value="<?php echo e(isset($student_class_register_info) && !empty($student_class_register_info)? $student_class_register_info->class_quiz_1 :''); ?>"/></td>
													<td><input type="text" id="ct_2_<?php echo e($course_list->course_code); ?>" class="form-control" name="ct_2"  value="<?php echo e(isset($student_class_register_info) && !empty($student_class_register_info)? $student_class_register_info->class_quiz_2 :''); ?>"/></td>
													<td><input type="text" id="ct_3_<?php echo e($course_list->course_code); ?>" class="form-control" name="ct_3"   value="<?php echo e(isset($student_class_register_info) && !empty($student_class_register_info)? $student_class_register_info->class_quiz_3 :''); ?>"/></td>
													<td><input type="text" id="ct_4_<?php echo e($course_list->course_code); ?>" class="form-control" name="ct_4" value="<?php echo e(isset($student_class_register_info) && !empty($student_class_register_info)? $student_class_register_info->class_quiz_4 :''); ?>"/>
													</td>
													
													<td><input type="text" id="class_attendance_<?php echo e($course_list->course_code); ?>" class="form-control" name="class_attendance"   value="<?php echo e(isset($student_class_register_info) && !empty($student_class_register_info)? $student_class_register_info->class_attendance :''); ?>"/></td>
													<td><input type="text" id="class_participation_<?php echo e($course_list->course_code); ?>" class="form-control" name="class_participation"   value="<?php echo e(isset($student_class_register_info) && !empty($student_class_register_info)? $student_class_register_info->class_participation :''); ?>"/></td>
													<td><input type="text" id="class_presentaion_<?php echo e($course_list->course_code); ?>" class="form-control" name="class_presentaion" value="<?php echo e(isset($student_class_register_info) && !empty($student_class_register_info)? $student_class_register_info->class_presentaion :''); ?>"/></td>
													<td><input type="text" id="mid_term_<?php echo e($course_list->course_code); ?>" class="form-control" name="mid_term" value="<?php echo e(isset($student_class_register_info) && !empty($student_class_register_info)? $student_class_register_info->class_mid_term_exam :''); ?>"/></td>
													<td><input type="text" id="class_final_exam_<?php echo e($course_list->course_code); ?>" class="form-control" name="class_final_exam" value="<?php echo e(isset($student_class_register_info) && !empty($student_class_register_info)? $student_class_register_info->class_final_exam :''); ?>"/></td>


	                                                <?php if(empty($student_class_register_info)): ?>

														<td>
															<!-- <button type="submit" data-loading-text="Saving..." data-course="<?php echo e($course_list->course_code); ?>" class="btn btn-primary btn-sm loadingButton ExamMarksStore" data-toggle="tooltip" title="Store Marks">Save</button> -->
															<input data-loading-text="Saving..." type="submit" value="Save" class="btn btn-primary btn-sm loadingButton" data-toggle="tooltip" title="Store Marks">
														</td>
													<?php else: ?>
														<td>
															<span><i class="fa fa-check" aria-hidden="true"></i><a  data-confirm-url="<?php echo e(url('/register/existing/student/delete/course/'.$_GET['student_no'].'/'.$course_list->course_code.'/'.$course_list->course_type.'/'.$student_class_register_info->class_year.'/'.$student_class_register_info->class_semster)); ?>" class="btn btn-danger btn-xs confirm_box" data-toggle="tooltip" title="Undo Course"><i class="fa fa-undo" aria-hidden="true"></i></a></span>
														</td>
													<?php endif; ?>

												</form>
													
												</tr>
												<?php endforeach; ?>

											</tbody>
										<?php endif; ?>

										<?php if(!empty($all_lab_course)): ?>

										<thead>
											<tr>
												<th class="text-center">SL</th>
												<th class="text-center">Course Title</th>
												<th colspan="3" class="text-center">Academic Year</th>
												<th colspan="2" class="text-center">Academic Semester</th>
												<th class="text-center">Lab Attendance(10%)</th>
												<th colspan="2" class="text-center">Lab Performance(40%)</th>
												<th colspan="2" class="text-center">Lab Report(40%)</th>
												<th colspan="2" class="text-center">Lab Verbal(40%)</th>
												<th colspan="2" class="text-center">Lab Final(40%)</th>
												<th>All</th>
											</tr>
										</thead>

										<tbody>
											<?php foreach($all_lab_course as $key => $course_list): ?>
											<tr>
											<form method="get" action="<?php echo e(url('/register/existing/student/lab/marks/submit')); ?>" enctype="multipart/form-data">

												<td><?php echo e($key+1); ?></td>
												<td>(<?php echo e($course_list->course_code); ?>) <?php echo e($course_list->course_title); ?></td>

												<?php 
														$student_lab_register_info=\DB::table('student_lab_register')
	                                                       ->where('student_tran_code',$student_info->student_tran_code)
	                                                       ->where('student_lab_register.lab_course_code',$course_list->course_code)
	                                                       ->first();

                                                ?>

												<td colspan="3">
													<select class="form-control" id="course_year_<?php echo e($course_list->course_code); ?>" name="course_year">
														<option value="">Select Year</option>
														<?php if(!empty($univ_academic_calender)): ?>
														<?php foreach($univ_academic_calender as $key => $list): ?>

														<option <?php echo e(isset($student_lab_register_info) && !empty($student_lab_register_info) && $student_lab_register_info->lab_year == date("Y",strtotime("-5 year")) ? 'selected' :''); ?>   value="<?php echo e(date("Y",strtotime("-5 year"))); ?>"><?php echo e(date("Y",strtotime("-5 year"))); ?></option>


														<option <?php echo e(isset($student_lab_register_info) && !empty($student_lab_register_info) && $student_lab_register_info->lab_year == date("Y",strtotime("-4 year")) ? 'selected' :''); ?>   value="<?php echo e(date("Y",strtotime("-4 year"))); ?>"><?php echo e(date("Y",strtotime("-4 year"))); ?></option>
														<option <?php echo e(isset($student_lab_register_info) && !empty($student_lab_register_info) && $student_lab_register_info->lab_year == date("Y",strtotime("-3 year")) ? 'selected' :''); ?>  value="<?php echo e(date("Y",strtotime("-3 year"))); ?>"><?php echo e(date("Y",strtotime("-3 year"))); ?></option>
														<option <?php echo e(isset($student_lab_register_info) && !empty($student_lab_register_info) && $student_lab_register_info->lab_year == date("Y",strtotime("-2 year")) ? 'selected' :''); ?>  value="<?php echo e(date("Y",strtotime("-2 year"))); ?>"><?php echo e(date("Y",strtotime("-2 year"))); ?></option>
														<option <?php echo e(isset($student_lab_register_info) && !empty($student_lab_register_info) && $student_lab_register_info->lab_year == date("Y",strtotime("-1 year")) ? 'selected' :''); ?>  value="<?php echo e(date("Y",strtotime("-1 year"))); ?>"><?php echo e(date("Y",strtotime("-1 year"))); ?></option>
														<option <?php echo e(isset($student_lab_register_info) && !empty($student_lab_register_info) && $student_lab_register_info->lab_year == date("Y") ? 'selected' :''); ?> value="<?php echo e(date('Y')); ?>"><?php echo e(date('Y')); ?></option>
														<option<?php echo e(isset($student_lab_register_info) && !empty($student_lab_register_info) && $student_lab_register_info->lab_year == date("Y",strtotime("+1 year")) ? 'selected' :''); ?>   value="<?php echo e(date("Y",strtotime("+1 year"))); ?>"><?php echo e(date("Y",strtotime("+1 year"))); ?></option>

														<?php endforeach; ?>
														<?php endif; ?>
													</select>	
												</td>
											
												<td colspan="2">
													<select class="form-control" id="course_semester_<?php echo e($course_list->course_code); ?>" name="course_semester" >
														<option value="">Select Semester</option>
														<?php if(!empty($all_semester)): ?>
														<?php foreach($all_semester as $key => $list): ?>

														<option <?php echo e(isset($student_lab_register_info) && !empty($student_lab_register_info) && $student_lab_register_info->lab_semster == $list->semester_code? 'selected' :''); ?>

															  value="<?php echo e($list->semester_code); ?>"><?php echo e($list->semester_title); ?></option>

														<?php endforeach; ?>
														<?php endif; ?>
													</select>	
												</td>

												<input type="hidden" class="form-control" id="student_serial_no_<?php echo e($course_list->course_code); ?>" name="student_serial_no" value="<?php echo e($student_info->student_serial_no); ?>" />
												<input type="hidden" class="form-control" id="course_type_<?php echo e($course_list->course_code); ?>" name="course_type" value="<?php echo e($course_list->course_type); ?>" />
												<input type="hidden" class="form-control" name="course_code" value="<?php echo e($course_list->course_code); ?>" />
												<td><input type="text" id="lab_attendance_<?php echo e($course_list->course_code); ?>" class="form-control" name="lab_attendance" value="<?php echo e(isset($student_lab_register_info)? $student_lab_register_info->lab_attendance :''); ?>"/></td>
												<td colspan="2"><input type="text" id="lab_performance_<?php echo e($course_list->course_code); ?>" class="form-control" name="lab_performance" value="<?php echo e(isset($student_lab_register_info)? $student_lab_register_info->lab_performance :''); ?>"/></td>
												<td colspan="2"><input type="text" id="lab_reprot_<?php echo e($course_list->course_code); ?>" class="form-control" name="lab_reprot" value="<?php echo e(isset($student_lab_register_info)? $student_lab_register_info->lab_reprot :''); ?>"/></td>
												<td colspan="2"><input type="text" id="lab_verbal_<?php echo e($course_list->course_code); ?>" class="form-control" name="lab_verbal" value="<?php echo e(isset($student_lab_register_info)? $student_lab_register_info->lab_verbal :''); ?>"/></td>
												<td colspan="2"><input type="text" id="lab_final_<?php echo e($course_list->course_code); ?>" class="form-control" name="lab_final" value="<?php echo e(isset($student_lab_register_info)? $student_lab_register_info->lab_final :''); ?>"/></td>

                                                <?php if(empty($student_lab_register_info)): ?>
													<td>
														<!-- <button type="submit" data-loading-text="Saving..." data-course="<?php echo e($course_list->course_code); ?>" class="btn btn-primary btn-sm loadingButton ExamMarksStore" data-toggle="tooltip" title="Store Marks">Save</button> -->
														<input data-loading-text="Saving..." type="submit" value="Save" class="btn btn-primary btn-sm loadingButton" data-toggle="tooltip" title="Store Marks">
														
													</td>
												<?php else: ?>
													<td>
														<span><i class="fa fa-check" aria-hidden="true"></i><a data-confirm-url="<?php echo e(url('/register/existing/student/delete/course/'.$_GET['student_no'].'/'.$course_list->course_code.'/'.$course_list->course_type.'/'.$student_lab_register_info->lab_year.'/'.$student_lab_register_info->lab_semster)); ?>" class="btn btn-danger btn-xs confirm_box" data-toggle="tooltip" title="Undo Course"><i class="fa fa-undo" aria-hidden="true"></i></a></span>
														
													</td>
												<?php endif; ?>

											</form>
											</tr>
											<?php endforeach; ?>
										</tbody>
										<?php endif; ?>

									</table>
									<br><br>

								<?php endif; ?>

						</div>
					</div>
					<?php endif; ?>
				</div>


			</div>

		</div>
	</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>