<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layout.bradecrumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<!--error message*******************************************-->
<div class="row page_row">
	<div class="col-md-12">
		<?php if($errors->count() > 0 ): ?>

		<div class="alert alert-danger">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<h6>The following errors have occurred:</h6>
			<ul>
				<?php foreach( $errors->all() as $message ): ?>
				<li><?php echo e($message); ?></li>
				<?php endforeach; ?>
			</ul>
		</div>
		<?php endif; ?>

		<?php if(Session::has('message')): ?>
		<div class="alert alert-success" role="alert">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<?php echo e(Session::get('message')); ?>

		</div> 
		<?php endif; ?>

		<?php if(Session::has('errormessage')): ?>
		<div class="alert alert-danger" role="alert">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<?php echo e(Session::get('errormessage')); ?>

		</div>
		<?php endif; ?>

	</div>
</div>
<!--end of error message*************************************-->

<div class="row page_row">
	<div class="col-md-12">
		<div class="panel panel-body padding_0 ">
			<!-- sorting_form -->
			<form action="<?php echo e(url('/faculty/student/attendance/percent')); ?>" method="get" enctype="multipart/form-data">


				<div class="form-group col-md-3">
					<label for="Program">Program</label>
					<select class="form-control " name="program" >
						<option value="0">Select Program</option>
						<?php if(!empty($program_list)): ?>

							<option <?php echo e((isset($_GET['program']) && ($_GET['program'] == $program_list->program_id)) ? 'selected' : ''); ?> value="<?php echo e($program_list->program_id); ?>"><?php echo e($program_list->program_title); ?></option>

						<?php endif; ?>
					</select>
				</div>



				<div class="form-group col-md-3">
					<label for="Semester">Trimester</label>
					<select class="form-control " name="semester" >
						<option value="0">Select Trimester</option>
						<?php if(!empty($semester_list)): ?>
						<?php foreach($semester_list as $key => $list): ?>
						<option <?php echo e((isset($_GET['semester']) && ($_GET['semester'] == $list->semester_code)) ? 'selected' : ''); ?> value="<?php echo e($list->semester_code); ?>"><?php echo e($list->semester_title); ?></option>
						<?php endforeach; ?>
						<?php endif; ?>
					</select>
				</div>

				<div class="form-group col-md-2">
					<label for="AcademicYear">Academic Year</label>
					<select class="form-control " name="academic_year" >
						<option value="0">Select Year</option>
						<?php if(!empty($univ_academic_calender)): ?>
						<?php foreach($univ_academic_calender as $key => $list): ?>
						<option <?php echo e((isset($_GET['academic_year']) && ($_GET['academic_year']==$list->academic_calender_year)) ? 'selected' : ''); ?> value="<?php echo e($list->academic_calender_year); ?>"><?php echo e($list->academic_calender_year); ?></option>
						<?php endforeach; ?>
						<?php endif; ?>
					</select>
				</div>



				<div class="form-group col-md-3">
					<label for="Course">Course</label>
					<select class="form-control " name="course">
						<option value="0">Select Course</option>
						<?php if(!empty($course_list)): ?>
						<?php foreach($course_list as $key => $list): ?>
						<option  <?php echo e((isset($_GET['course']) && ($_GET['course']==$list->assigned_course_id)) ? 'selected' : ''); ?> value="<?php echo e($list->assigned_course_id); ?>"><?php echo e($list->assigned_course_id); ?> <?php echo e($list->assigned_course_title); ?></option>
						<?php endforeach; ?>
						<?php endif; ?>
					</select>
				</div>

				<div class="col-md-1 margin_top_20" style="margin-top:26px;">
					<button class="btn btn-danger register_attendance_list_search" data-toggle="tooltip" title="Search Student">Serach</button>
				</div>
			</form>

		</div>
	</div>
</div>

<?php if(!empty($_GET['program']) && !empty($_GET['semester']) && !empty($_GET['academic_year']) && !empty($_GET['course'])): ?>

<div class="row page_row">
	<div class="col-md-12">

		<div class="panel panel-body padding_0">

				<table class="table table-bordered table-hover">
					<thead>
						<tr>
							<th>SL</th>
							<th>Student ID</th>
							<th>Student Name</th>
							<th>Program</th>
							<th>Course Code</th>
							<th>Course Title</th>
							<th>Total Class</th>
							<th>Attend</th>
							<th>Absence</th>
							<th>Attend Percent (%)</th>
						</tr>
					</thead>

					<tbody>
							<?php if(!empty($all_student_attendance_info)): ?>
								<?php foreach($all_student_attendance_info as $key => $student_list): ?>

									<?php 
										$all_student_attendance_information=unserialize($student_list);
									?>
										<tr>
											<td><?php echo e($key+1); ?></td>
									    	<?php foreach($all_student_attendance_information as $key2 => $list): ?> 
											<td><?php echo e($all_student_attendance_information[$key2]); ?></td>

									    	<?php endforeach; ?>
										</tr>


								<?php endforeach; ?>
							<?php else: ?>
								<tr>
									<td colspan="10">
										<div class="alert alert-success">
											<center><h3 style="font-style:italic">No Data Available !</h3></center>
										</div>
									</td>
								</tr>
							<?php endif; ?>



					</tbody>
				</table>

			</div>
		</div>

	</div>

	<?php else: ?>

	<div class="row page_row">
		<div class="col-md-12">
			<div class="alert alert-success">
				<center><h3 style="font-style:italic">No Data Available !</h3></center>
			</div>
		</div>
	</div>

	<?php endif; ?>

	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>