<?php if(!empty($faculty_list)): ?>
		<option value="">Select Faculty</option>
	<?php foreach($faculty_list as $key => $list): ?>
		<option value="<?php echo e($list->faculty_id); ?>"><?php echo e(trim($list->first_name.' '.$list->middle_name.' '.$list->last_name)); ?> <?php echo e(($list->faculty_id)); ?></option>
	<?php endforeach; ?>
<?php else: ?>
	<option value="">Select Faculty</option>
<?php endif; ?>