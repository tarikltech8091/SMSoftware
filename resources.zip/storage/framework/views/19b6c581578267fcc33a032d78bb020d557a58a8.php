<?php $__env->startSection('content'); ?>
<style type="text/css">
	.texting{
		background-color: #19a15f;
		border: 1px solid;
	}
	.heading{
		text-align: center;
		font-weight: bolder;
		background-color: #92cddc;
		border: 1px solid;
		color: #000;
		font-size: 18px;
	}

	
</style>
<table class="table table-striped table-bordered table-hover applicant_register">
	<thead>

		<tr>
			<th class="heading" colspan="7">APPLICANT LIST</th>					
		</tr>
		<tr>
			<th>SL No.</th>
			<th>Applicant ID</th>
			<th>Applicant Name</th>
			<th>Program</th>
			<th>Trimester</th>
			<th>Academic Year</th>
			<th>Remarks</th>
			
		</tr>
	</thead>
	<tbody>
		<?php if(count($all_applicant)>0): ?>
		
		<?php foreach($all_applicant as $key => $applicant): ?>
		
		<tr>
			<td ><?php echo e(($key+1)); ?></td>
			<td ><?php echo e($applicant->applicant_serial_no); ?></td>
			<td><?php echo e($applicant->first_name); ?> <?php echo e($applicant->middle_name); ?> <?php echo e($applicant->last_name); ?></td>
			<td><?php echo e($applicant->program_code); ?></td>
			<td><?php echo e(strtoupper($applicant->semester_title)); ?></td>
			<td><?php echo e($applicant->academic_year); ?></td>

			<?php if($applicant->applicant_eligiblity==3): ?>
			<td >Merit Listed</td>
			<?php elseif($applicant->applicant_eligiblity==2): ?>
			<td >Waiting Listed</td>
			<?php endif; ?>
			
		</tr>

		<?php endforeach; ?>
		<?php else: ?>
		<tr class="text-center">
			<td colspan="7">No Data available</td>
		</tr>
		
		<?php endif; ?>
	</tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('excelsheet.layout.master-excel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>