<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layout.bradecrumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<!--error message*******************************************-->
<div class="row page_row">
	<div class="col-md-12">
		<?php if($errors->count() > 0 ): ?>

		<div class="alert alert-danger">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<h6>The following errors have occurred:</h6>
			<ul>
				<?php foreach( $errors->all() as $message ): ?>
				<li><?php echo e($message); ?></li>
				<?php endforeach; ?>
			</ul>
		</div>
		<?php endif; ?>

		<?php if(Session::has('message')): ?>
		<div class="alert alert-success" role="alert">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<?php echo e(Session::get('message')); ?>

		</div> 
		<?php endif; ?>

		<?php if(Session::has('errormessage')): ?>
		<div class="alert alert-danger" role="alert">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<?php echo e(Session::get('errormessage')); ?>

		</div>
		<?php endif; ?>

	</div>
</div>
<!--end of error message*************************************-->

<div class="row page_row">
	<div class="col-md-12 form-inline">
		<div class="col-md-12 panel panel-body search_panel_bg_color">
			<form method="get" action="<?php echo e(url('/register/student/batch-semester/change')); ?>" enctype="multipart/form-data">
				<div class="form-group col-md-6">
					<input  class="form-control search_width" type="text" name="student_no" value="<?php echo e(!empty($_GET['student_no'])? $_GET['student_no'] : old('student_no')); ?>" placeholder="Search Student...">

					<button type="submit" class="btn btn-default" data-toggle="tooltip" title="Search Student">Serach !</button>

				</div>

			</form>
		</div>
	</div>
</div>
<?php if(isset($_GET['student_no'])): ?>
<?php if(!empty($_GET['student_no'])): ?>
<div class="row page_row">
	<div class="col-md-12">
		<div class="panel panel-body padding_0">

				<br><h2 align="center"><strong>Student Change Info</strong></h2><br>
				<table class="table table-bordered table-hover">
					<thead>
						<tr>
							<th>Student ID</th>
							<th>Program</th>
							<th>Admission Year</th>
							<th>Admission Semester</th>
							<th>Batch</th>
							<th>Action</th>
						</tr>
					</thead>

					<tbody>
						<?php if(!empty($select_student)): ?>
						<form action="<?php echo e(url('/register/student/batch-semester/change/confirm')); ?>" method="post" enctype="multipart/form-data">
							<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

							<tr>
								<td><?php echo e($select_student->student_serial_no); ?></td>
								<td><?php echo e($select_student->program_title); ?></td>
								<td><input type="text" class="form-control" name="change_year" value="<?php echo e($select_student->academic_year); ?>"/></td>
								<td>
									<?php
									$semester_list=\DB::table('univ_semester')->get();
									?>
									<select class="form-control" name="change_semester" >
										<?php if(!empty($semester_list)): ?>
										<?php foreach($semester_list as $key => $list): ?>
										<option <?php echo e((isset($select_student->semester) && ($select_student->semester==$list->semester_code)) ? 'selected':''); ?> value="<?php echo e($list->semester_code); ?>"><?php echo e($list->semester_title); ?></option>
										<?php endforeach; ?>
										<?php endif; ?>
									</select>

								</td>
								<td><input type="text" class="form-control" name="change_batch" value="<?php echo e($select_student->batch_no); ?>"/>
									<input type="hidden" name="student_no" value="<?php echo e($select_student->student_serial_no); ?>"/>
								</td>
								<td><button type="submit" class="btn btn-primary btn-sm">Submit</button></td>

							</tr>
						</form>

						<?php else: ?>
						<tr>
							<td colspan="5">
								<div class="alert alert-success">
									<center><h3 style="font-style:italic">No Data Available !</h3></center>
								</div>
							</td>
						</tr>
						<?php endif; ?>


					</tbody>
				</table>
		</div>

	</div>
</div>
<?php else: ?>
<div class="page_row row">
	<div class="col-md-12">
		<div class="alert alert-success">
			<center><h3 style="font-style:italic">No Data Found !</h3></center>
		</div>
	</div>
</div>
<?php endif; ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>