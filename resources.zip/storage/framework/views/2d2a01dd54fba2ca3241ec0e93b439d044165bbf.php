<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layout.bradecrumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--error message*******************************************-->

<div class="row page_row">

	<div class="col-md-12">
		<?php if($errors->count() > 0 ): ?>

		<div class="alert alert-danger">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<h6>The following errors have occurred:</h6>
			<ul>
				<?php foreach( $errors->all() as $message ): ?>
				<li><?php echo e($message); ?></li>
				<?php endforeach; ?>
			</ul>
		</div>
		<?php endif; ?>

		<?php if(Session::has('message')): ?>
		<div class="alert alert-success" role="alert">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<?php echo e(Session::get('message')); ?>

		</div> 
		<?php endif; ?>

		<?php if(Session::has('errormessage')): ?>
		<div class="alert alert-danger" role="alert">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<?php echo e(Session::get('errormessage')); ?>

		</div>
		<?php endif; ?>

	</div>
</div>

<!--end of error message*************************************-->


<div class="row page_row">
	<div class="col-md-12  profile_tab">
		<div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
			
			<ul id="myTab" class="nav nav-tabs" role="tablist">

				<li role="presentation" class="<?php echo e($tab=='student_info' ? 'active' :''); ?>"><a href="#student_info" role="tab" id="student_info-tab" data-toggle="tab" aria-controls="student_info"><i class="fa fa-info-circle" aria-hidden="true"></i>Student Info</a></li>
				<li role="presentation" class="<?php echo e($tab=='accepted_course' ? 'active' :''); ?>"><a href="#accepted_course" role="tab" id="accepted_course-tab" data-toggle="tab" aria-controls="accepted_course"><i class="fa fa-book"></i>Accepted Course</a></li>

			</ul>


			<div id="myTabContent" class="tab-content"><!--main tab content-->
				<div role="tabpanel"  id="student_info"  class="tab-pane fade <?php echo e($tab=='student_info' ? 'in active' :''); ?>" aria-labelledby="student_info-tab">
					<div class="row">
						<div class="col-md-10">
							<div class="panel panel-body page_row">
								<div class="alert alert-info">
									<h3>Student Information</h3><br>

									<form action="<?php echo e(url('/register/student/credit/transfer/submit')); ?>" method="post" enctype="multipart/form-data">
										<div class="row"><!--basic block form -->
											<div class="col-md-12">
												<div class="row">
													<div class="form-group col-md-4">
														<label for="First Name">First Name<span class="required-sign">*</span></label>
														<input type="text" class="form-control uppercase_name" name="first_name" placeholder="First Name" value="<?php echo e(old('first_name')); ?>">
													</div>
													<div class="form-group col-md-4">
														<label for="Middle Name">Middle Name</label>
														<input type="text" class="form-control uppercase_name" name="middle_name" placeholder="Middle Name" value="<?php echo e(old('middle_name')); ?>">
													</div>
													<div class="form-group col-md-4">
														<label for="Last Name">Last Name<span class="required-sign">*</span></label>
														<input type="text" class="form-control uppercase_name" name="last_name" placeholder="Last Name" value="<?php echo e(old('last_name')); ?>">
													</div>
												</div>

												<?php 
												$program_list =\App\Register::ProgramList();
												?>
												<div class="row">
													<div class="form-group col-md-4">
														<label for="Program">Program<span class="required-sign">*</span></label>
														<select class="form-control" name="program">
															<?php if(!empty($program_list)): ?>
															<?php foreach($program_list as $key => $list): ?>
															<option <?php echo e((old('program')== $list->program_id) ? "selected" :''); ?> value="<?php echo e($list->program_id); ?>"><?php echo e($list->program_title); ?></option>
															<?php endforeach; ?>
															<?php endif; ?>
														</select> 
													</div>
													<div class="form-group col-md-4">
														<label for="Semester">Trimester<span class="required-sign">*</span></label>
														<?php
														$semester_list=\DB::table('univ_semester')->get();
														?>
														<select class="form-control" name="semester">
															<?php if(!empty($semester_list)): ?>
															<?php foreach($semester_list as $key => $semester): ?>
															<option <?php echo e((old('semester')== $semester->semester_code) ? "selected" :''); ?> value="<?php echo e($semester->semester_code); ?>"><?php echo e($semester->semester_title); ?></option>
															<?php endforeach; ?>
															<?php endif; ?>
														</select>
													</div>

													<div class="form-group col-md-4">
														<label for="AcademicYear">Academic Year<span class="required-sign">*</span></label>
														<select class="form-control" name="academic_year">
					
															<option <?php echo e((isset($academic_year) && ($academic_year==date('Y'))) ? 'selected':''); ?>  value="<?php echo e(date('Y')); ?>"><?php echo e(date('Y')); ?></option>
															<option <?php echo e((isset($academic_year) && ($academic_year==date('Y',strtotime('+1 year')))) ? 'selected':''); ?> value="<?php echo e(date("Y",strtotime('+1 year'))); ?>"><?php echo e(date('Y',strtotime("+1 year"))); ?></option>
														</select>
													</div>
												</div>
											</div>

										</div><!-- /basic block form -->

										<hr style="border-width: 1px;">
										<br>
										<div class="row"><!--academic form-->
											<div class="col-md-12">
												<div class="form-group col-md-2">
													<label >Exam Type<span class="required-sign">*</span></label>
													<select class="form-control" name="ssc_exam_type" >
														<option  <?php echo e((old('ssc_exam_type')== "SSC") ? "selected" :''); ?> value="SSC">SSC</option>
														<option  <?php echo e((old('ssc_exam_type')== "olevel") ? "selected" :''); ?> value="olevel">O level</option>
													</select>
												</div>
												<div class="form-group col-md-2">
													<label >Group<span class="required-sign">*</span></label>
													<select class="form-control" name="ssc_group_name">
														<option <?php echo e((old('ssc_group_name')== "science") ? "selected" :''); ?> value="science">Science</option>
														<option <?php echo e((old('ssc_group_name')== "arts") ? "selected" :''); ?> value="arts">Arts</option>
														<option <?php echo e((old('ssc_group_name')== "commerce") ? "selected" :''); ?> value="commerce">Commerce</option>
													</select>
												</div>

												<div class="form-group col-md-2">
													<label >Roll Number<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="ssc_roll_number"  value="<?php echo e(old('ssc_roll_number')); ?>" >
												</div>
												<div class="form-group col-md-2">
													<label >Board<span class="required-sign">*</span></label>
													<select  class="form-control" name="ssc_board_name">
														<option  <?php echo e((old('ssc_board_name')== 0) ? "selected" :''); ?> value="0">Select One</option>
														<option  <?php echo e((old('ssc_board_name')== "barisal") ? "selected" :''); ?> value="barisal">Barisal</option>
														<option  <?php echo e((old('ssc_board_name')== "chittagong") ? "selected" :''); ?> value="chittagong">Chittagong</option>
														<option  <?php echo e((old('ssc_board_name')== "comilla") ? "selected" :''); ?> value="comilla">Comilla</option>
														<option  <?php echo e((old('ssc_board_name')== "dhaka") ? "selected" :''); ?> value="dhaka">Dhaka</option>
														<option  <?php echo e((old('ssc_board_name')== "dinajpur") ? "selected" :''); ?> value="dinajpur">Dinajpur</option>
														<option  <?php echo e((old('ssc_board_name')== "jessore") ? "selected" :''); ?> value="jessore">Jessore</option>
														<option  <?php echo e((old('ssc_board_name')== "rajshahi") ? "selected" :''); ?> value="rajshahi">Rajshahi</option>
														<option  <?php echo e((old('ssc_board_name')== "sylhet") ? "selected" :''); ?> value="sylhet">Sylhet</option>
														<option  <?php echo e((old('ssc_board_name')== "madrasah") ? "selected" :''); ?> value="madrasah">Madrasah</option>
														<option  <?php echo e((old('ssc_board_name')== "technical") ? "selected" :''); ?> value="technical">Technical</option>
														<option  <?php echo e((old('ssc_board_name')== "dibs") ? "selected" :''); ?> value="dibs">DIBS(Dhaka)</option>
													</select>
												</div>
												<div class="form-group col-md-2">
													<label >Passing Year<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="ssc_olevel_year" placeholder="Year" value="<?php echo e(old('ssc_olevel_year')); ?>" >
												</div>
												<div class="form-group col-md-2">
													<label class="control-label ">Total GPA<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="total_ssc_olevel_gpa" placeholder="Total GPA" value="<?php echo e(old('total_ssc_olevel_gpa')); ?>" >
												</div>
											</div>


											<hr style="border-width: 1px;">
											<br>

											<div class="col-md-12">
												<div class="form-group col-md-2">
													<label >Exam Type<span class="required-sign">*</span></label>
													<select class="form-control" name="hsc_exam_type" >
														<option  <?php echo e((old('hsc_exam_type')== "HSC") ? "selected" :''); ?> value="HSC">HSC</option>
														<option  <?php echo e((old('hsc_exam_type')== "Alevel") ? "selected" :''); ?> value="alevel">A level</option>
													</select>
												</div>
												<div class="form-group col-md-2">
													<label >Group<span class="required-sign">*</span></label>
													<select class="form-control" name="hsc_group_name">
														<option <?php echo e((old('hsc_group_name')== "science") ? "selected" :''); ?> value="science">Science</option>
														<option <?php echo e((old('hsc_group_name')== "arts") ? "selected" :''); ?> value="arts">Arts</option>
														<option <?php echo e((old('hsc_group_name')== "commerce") ? "selected" :''); ?> value="commerce">Commerce</option>
													</select>
												</div>

												<div class="form-group col-md-2">
													<label >Roll Number<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="hsc_roll_number" value="<?php echo e(old('hsc_roll_number')); ?>">
												</div>
												<div class="form-group col-md-2">
													<label >Board<span class="required-sign">*</span></label>
													<select  class="form-control" name="hsc_board_name">
														<option  <?php echo e((old('hsc_board_name')== 0) ? "selected" :''); ?> value="0"selected>Select One</option>
														<option  <?php echo e((old('hsc_board_name')== "barisal") ? "selected" :''); ?> value="barisal">Barisal</option>
														<option  <?php echo e((old('hsc_board_name')== "chittagong") ? "selected" :''); ?> value="chittagong">Chittagong</option>
														<option  <?php echo e((old('hsc_board_name')== "comilla") ? "selected" :''); ?> value="comilla">Comilla</option>
														<option  <?php echo e((old('hsc_board_name')== "dhaka") ? "selected" :''); ?> value="dhaka">Dhaka</option>
														<option  <?php echo e((old('hsc_board_name')== "dinajpur") ? "selected" :''); ?> value="dinajpur">Dinajpur</option>
														<option  <?php echo e((old('hsc_board_name')== "jessore") ? "selected" :''); ?> value="jessore">Jessore</option>
														<option  <?php echo e((old('hsc_board_name')== "rajshahi") ? "selected" :''); ?> value="rajshahi">Rajshahi</option>
														<option  <?php echo e((old('hsc_board_name')== "sylhet") ? "selected" :''); ?> value="sylhet">Sylhet</option>
														<option  <?php echo e((old('hsc_board_name')== "madrasah") ? "selected" :''); ?> value="madrasah">Madrasah</option>
														<option  <?php echo e((old('hsc_board_name')== "technical") ? "selected" :''); ?> value="technical">Technical</option>
														<option  <?php echo e((old('hsc_board_name')== "dibs") ? "selected" :''); ?> value="dibs">DIBS(Dhaka)</option>
													</select>
												</div>
												<div class="form-group col-md-2">
													<label >Passing Year<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="hsc_olevel_year" placeholder="Year" value="<?php echo e(old('hsc_olevel_year')); ?>">
												</div>
												<div class="form-group col-md-2">
													<label class="control-label ">Total GPA<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="total_hsc_olevel_gpa" placeholder="Total GPA" value="<?php echo e(old('total_hsc_olevel_gpa')); ?>" >
												</div>
											</div>

										</div><!--/academic form-->
										<hr style="border-width: 1px;">
										<br>

										<div class="row"><!--personal form-->

											<div class="col-md-12">
												<div class="form-group col-md-4">
													<label for="City">Birth Place: City<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="place_of_birth" placeholder="Place Of Birth" value="<?php echo e(old('place_of_birth')); ?>" >	
												</div>

												<div class="form-group col-md-4">
													<label >Nationality<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="nationality" placeholder="Nationality" value="<?php echo e(old('nationality')); ?>" >
												</div>
												<div class="form-group col-md-4">
													<label for="Gender">Gender<span class="required-sign">*</span></label>
													<select class="form-control" name="gender">
														<option <?php echo e((old('gender')== "male") ? "selected" :''); ?> value="male">Male</option>
														<option <?php echo e((old('gender')== "female") ? "selected" :''); ?> value="female">Female</option>
													</select>
												</div>
											</div>
											<div class="col-md-12">

												<div class="form-group col-md-3">
													<label for="Batch">Student Batch <span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="batch" placeholder="Batch" value="<?php echo e(old('batch')); ?>">
												</div>

												<div class="form-group col-md-3">
													<div class="control-group">
														<label class="control-label">Date of Birth <span class="required-sign">*</span></label>
														<div class="input-group date date_of col-md-12" data-date="" data-count="1" data-date-format="yyyy-mm-dd" data-link-field="date_of_birth" data-link-format="yyyy-mm-dd">
															<input class="form-control" name="date_of_birth"  size="16" type="text" value="" readonly>
															<span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
															<span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
														</div>
													</div>
												</div>

												<div class="form-group col-md-3">
													<label >Blood Group</label>
													<select class="form-control" name="blood_group">
														<option <?php echo e((old('blood_group')== "") ? "selected" :''); ?>  value="">Select Blood Group</option>
														<option <?php echo e((old('blood_group')== "A+") ? "selected" :''); ?>  value="A+">A (+)</option>
														<option <?php echo e((old('blood_group')== "A-") ? "selected" :''); ?> value="A-">A (-)</option>
														<option <?php echo e((old('blood_group')== "AB+") ? "selected" :''); ?> value="AB+">AB (+)</option>
														<option <?php echo e((old('blood_group')== "AB-") ? "selected" :''); ?> value="AB-">AB (-)</option>
														<option <?php echo e((old('blood_group')== "O+") ? "selected" :''); ?>  value="O+">O (+)</option>
														<option <?php echo e((old('blood_group')== "O-") ? "selected" :''); ?> value="O-">O (-)</option>
														<option <?php echo e((old('blood_group')== "B+") ? "selected" :''); ?> value="B+">B (+)</option>
														<option <?php echo e((old('blood_group')== "B-") ? "selected" :''); ?> value="B-">B (-)</option>
													</select>
												</div>
												<div class="form-group col-md-3">
													<label >Marital Status</label>
													<select class="form-control" name="marital_status">
														<option <?php echo e((old('marital_status')== "single") ? "selected" :''); ?> value="single">Single</option>
														<option <?php echo e((old('marital_status')== "married") ? "selected" :''); ?> value="married">Married</option>
														<option <?php echo e((old('marital_status')== "other") ? "selected" :''); ?> value="other">Other</option>
													</select>
												</div>
											</div>



											<div class="col-md-12">
												<div class="form-group col-md-3">
													<label for="Religion">Religion<span class="required-sign">*</span></label>
													<select class="form-control" name="religion">
														<option <?php echo e((old('religion')== "") ? "selected" :''); ?>  value="">Select Religion</option>
														<option <?php echo e((old('religion')== "islam") ? "selected" :''); ?>  value="islam">Islam</option>
														<option <?php echo e((old('religion')== "christianity") ? "selected" :''); ?> value="christianity">Christianity</option>
														<option <?php echo e((old('religion')== "hinduism") ? "selected" :''); ?> value="hinduism">Hinduism</option>
														<option <?php echo e((old('religion')== "buddhism") ? "selected" :''); ?> value="buddhism">Buddhism</option>
														<option <?php echo e((old('religion')== "others") ? "selected" :''); ?> value="others">Others</option>

													</select> 	
												</div>
												<div class="form-group col-md-3">
													<label for="Email">Email<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="email" placeholder="abcd@gmail.com" value="<?php echo e(old('email')); ?>">	
												</div>
												<div class="form-group col-md-3">
													<label for="Phone">Phone</label>
													<input type="text" class="form-control" name="phone" placeholder="9300000" value="<?php echo e(old('phone')); ?>" >	
												</div>
												<div class="form-group col-md-3">
													<label >Mobile<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="mobile" placeholder="01000000000" value="<?php echo e(old('mobile')); ?>" >
												</div>
												<input type="hidden" name="image_url" id="image_url">
											</div>

										</div><!--/personal form-->

										<hr style="border-width: 1px;">
										<br>
										<div class="row"><!--contact and address form-->
											<div class="col-md-12">
												<div class="form-group col-md-3">
													<label >Present Address<span class="required-sign">*</span></label>
													<textarea class="form-control" name="present_address_detail" rows="1"></textarea>

												</div>
												<div class="form-group col-md-3">
													<label>Postal Code<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="present_postal_code" value="<?php echo e(old('present_postal_code')); ?>" placeholder="Postal Code" >
												</div>
												<div class="form-group col-md-3">
													<label >City<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="present_city" placeholder="City" value="<?php echo e(old('present_city')); ?>" >
												</div>
												<div class="form-group col-md-3">
													<label>Country<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="present_country" value="<?php echo e(old('present_country')); ?>" placeholder="Country" >
												</div>
											</div>
											<div class="col-md-12">
												<div class="form-group col-md-3">
													<label >Permanent Address<span class="required-sign">*</span></label>
													<textarea class="form-control" name="permanent_address_detail" rows="1" > </textarea>
												</div>
												<div class="form-group col-md-3">
													<label>Postal Code<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="permanent_postal_code" placeholder="Postal Code" value="<?php echo e(old('permanent_postal_code')); ?>" >
												</div>
												<div class="form-group col-md-3">
													<label >City<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="permanent_city" placeholder="City" value="<?php echo e(old('permanent_city')); ?>" >
												</div>
												<div class="form-group col-md-3">
													<label>Country<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="permanent_country" placeholder="Country" value="<?php echo e(old('permanent_country')); ?>" >
												</div>
											</div>


											<div class="col-md-12">
												<div class="form-group col-md-3">
													<label >Father's Name<span class="required-sign">*</span></label>
													<input type="text" class="form-control uppercase_name" name="father_name" placeholder="Fathers Name" value="<?php echo e(old('father_name')); ?>" >
												</div>
												<div class="form-group col-md-3">
													<label >Father's Occupation<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="father_occupation" placeholder="Fathers Occupation" value="<?php echo e(old('father_occupation')); ?>" >
												</div>

												<div class="form-group col-md-3">
													<label>Mobile<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="father_contact_mobile" placeholder="Ex:- 01722000000" value="<?php echo e(old('father_contact_mobile')); ?>" >
												</div>
												<div class="form-group col-md-3">
													<label>Email</label>
													<input type="text" class="form-control" name="father_contact_email" placeholder="example@example.com" value="<?php echo e(old('father_contact_email')); ?>" >
												</div>
											</div>
											<div class="col-md-12">
												<div class="form-group col-md-3">
													<label >Mother's Name<span class="required-sign">*</span></label>
													<input type="text" class="form-control uppercase_name" name="mother_name" placeholder="Mothers Name" value="<?php echo e(old('mother_name')); ?>" >
												</div>
												<div class="form-group col-md-3">
													<label >Mother's Occupation<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="mother_occupation" placeholder="Mother's Occupation" value="<?php echo e(old('mother_occupation')); ?>" >
												</div>
												<div class="form-group col-md-3">
													<label>Mobile<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="mother_contact_mobile" placeholder="Ex:- 01000000000" value="<?php echo e(old('mother_contact_mobile')); ?>" >
												</div>
												<div class="form-group col-md-3">
													<label>Email</label>
													<input type="text" class="form-control" name="mother_contact_email" placeholder="example@example.com" value="<?php echo e(old('mother_contact_email')); ?>" >
												</div>
											</div>


											<div class="col-md-12">
												<div class="form-group col-md-3">
													<label >Local Guardian Name<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="local_guardian_name"  value="<?php echo e(old('local_guardian_name')); ?>">
												</div>
												<div class="form-group col-md-3">
													<label > Guardian Occupation<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="local_guardian_occupation" placeholder="Local Guardian Occupation" value="<?php echo e(old('local_guardian_occupation')); ?>" >
												</div>
												<div class="form-group col-md-3">
													<label> Guardian Mobile<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="local_guardian_contact_mobile" placeholder="Ex:- 01722000000" value="<?php echo e(old('local_guardian_contact_mobile')); ?>" >
												</div>
												<div class="form-group col-md-3">
													<label> Guardian Email</label>
													<input type="text" class="form-control" name="local_guardian_contact_email" placeholder="example@example.com" value="<?php echo e(old('local_guardian_contact_email')); ?>" >
												</div>
											</div>


											<div class="col-md-12">
												<div class="form-group col-md-3">
													<h4>Emergency contact:<span class="required-sign">*</span></h4>						
												</div>
												<div class="form-group col-md-5">
													<input type="radio" name="emergency_contact"  value="Father" > Father				
													<input type="radio" name="emergency_contact"  value="Mother" > Mother										
													<input type="radio" name="emergency_contact"  value="Local_Guardian" checked> Local Guardian										
												</div>
												<div class="form-group col-md-4">
													<label>Accepted credit :<span class="required-sign">*</span></label>
													<input type="text" class="form-control" name="no_of_accepted_credit" placeholder="No of accepted credit" value="<?php echo e(old('no_of_accepted_credit')); ?>" >
												</div>

												<?php
												$waiver_list=\DB::table('waivers')->get();
												?>
<!-- 												<div class="form-group col-md-3">
													<label>Waiver : </label>
													<select class="form-control" name="waiver">
														<option value="">Select Waiver Type</option>
														<?php if(!empty($waiver_list)): ?>
														<?php foreach($waiver_list as $key => $list): ?>
														<option <?php echo e((old('waiver')== $list->waiver_name_slug) ? "selected" :''); ?> value="<?php echo e($list->waiver_name_slug); ?>"><?php echo e($list->waiver_name); ?></option>
														<?php endforeach; ?>
														<?php endif; ?>
													</select> 
												</div> -->

											</div>
										</div>
										<hr>
										<div class="text-right" style="margin-top:30px;">
											<div class="col-md-12">
												
												<a href="<?php echo e(\Request::url()); ?>" class="btn btn-danger">Reset</a>
												<input type="submit" class="btn btn-primary" value="Submit">
											</div>
										</div><br><br>
									</form>
								</div>	
							</div> <!-- /panel body -->
						</div>



						<div class="col-md-2" style="margin-top:10px;">
							<div class="panel panel-default">
								<div class="panel-body">
									<div id="validation-errors"></div>
									<label>Passposrt Size Photo (Colored) <span class="required-sign">*</span></label>    
									<div id="demo">
										<img  src="<?php echo e(old('image_url') ? asset(old('image_url')):asset('images/profile.png')); ?>" alt="img">
									</div>
									<div class="uploader">
										<form class="example" id="upload" role="form" enctype="multipart/form-data" method="POST" action="<?php echo e(url('/register/student/credit/transfer/image-upload')); ?>" >
											<div class="fileinputs">
												<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />

												<span class="btn btn-primary btn-file span-photo"> 
													Browse Photo<input name="image" id="image_transfer_student" noscript="true" type="file" name="photo" class="form-control btn-file-browse-photo">
													
												</span>
												
											</div>

										</form>
										<div class='image_loader'></div>
										
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>


				<div role="tabpanel"  id="accepted_course"  class="tab-pane fade <?php echo e($tab=='accepted_course' ? 'in active' :''); ?>" aria-labelledby="accepted_course-tab">

					<div class="row page_row">
						<div class="col-md-12">
							<div class="panel panel-body padding_0 "><!--header inline form-->
								<!-- sorting_form -->
								<?php 
								$program_list =\App\Applicant::ProgramList();
								?>

								<div class="form-group col-md-3" style="margin-left:400px;">
									<label for="Program">Program</label>
									<select class="form-control courseprogram" name="program" >
										<option value="">Select Program</option>
										<?php if(!empty($program_list)): ?>
										<?php foreach($program_list as $key => $list): ?>

										<option <?php echo e((isset($_GET['program']) && ($_GET['program']==$list->program_id)) ? 'selected' : ''); ?> value="<?php echo e($list->program_id); ?>"><?php echo e($list->program_title); ?></option>

										<?php endforeach; ?>
										<?php endif; ?>
									</select>
								</div>
								<div class="col-md-1 margin_top_20" style="margin-top:25px;">
									<button class="btn btn-danger transfer_student_course_search" data-toggle="tooltip" title="Search Courses">Serach</button>
								</div>

							</div><!--/header inline form-->
						</div>
					</div>

					<?php if(!empty($_GET['program'])): ?>
					<div class="row">
						<div class="col-md-12" style="margin-bottom:20px; margin-top:20px;">
							<?php if(isset($_GET['program'])): ?>
							<div class="panel panel-body">
								<form action="<?php echo e(url('/register/student/accepted/course/submit')); ?>" method="post" enctype="multipart/form-data">
									<?php
									$student_id=\DB::table('student_basic')->where('student_status',3)->where('program',$_GET['program'])->get();
									?>
									<div class="form-group col-md-4" style="margin-left:400px;">
										<label for="Semester">Student List</label>
										<select class="form-control" name="student_no" >
											<option value="">Select Student</option>
											<?php if(!empty($student_id)): ?>
											<?php foreach($student_id as $key => $list): ?>

											<option <?php echo e((isset($_GET['student_no']) && ($_GET['student_no']==$list->student_serial_no)) ? 'selected' : ''); ?> value="<?php echo e($list->student_serial_no); ?>"><?php echo e($list->student_serial_no); ?></option>

											<?php endforeach; ?>
											<?php endif; ?>
										</select>									
									</div>

									<table class="table table-bordered table-hover padding_0">
										<thead>
											<tr>
												<th>SL</th>
												<th>Program</th>
												<th>Course Code</th>
												<th>Course Title</th>
												<th>Credit Hours</th>
												<th>Earn Grade Point</th>
												<th>Earn Grade</th>
												<th> <input class="checkAll" type="checkbox" /> All</th>
											</tr>
										</thead>

										<tbody>
											<?php if(!empty($all_course)): ?>
											<?php foreach($all_course as $key => $course_list): ?>
											<tr>
												<td><?php echo e($key+1); ?></td>
												<td><?php echo e($course_list->program_title); ?></td>
												<td><?php echo e($course_list->course_code); ?></td>
												<td><?php echo e($course_list->course_title); ?></td>
												<td><?php echo e($course_list->credit_hours); ?>

												</td>
												
												<div class="row">	
													<td><input type="text" name="tabulation_grade_point_<?php echo e($course_list->course_code); ?>" placeholder="Earn Grade Point"/></td>
													<td><input type="text" name="tabulation_grade_<?php echo e($course_list->course_code); ?>" placeholder="Earn Grade"/></td>
												</div>
												
												<td><input type="checkbox" name="course_no[]" value="<?php echo e($course_list->course_code); ?>"/></td>
											</tr>
											<?php endforeach; ?>
											<tr>
												<td colspan="8"><button type="submit" class="pull-right btn btn-primary btn-sm">Submit</button></td>
												
											</tr>
											<?php endif; ?>
										</tbody>
									</table>
								</form>
							</div>
							<?php else: ?>
							
							<div class="alert alert-success">
								<center><h3 style="font-style:italic">No Data Found !</h3></center>
							</div>
							<?php endif; ?>
						</div>
					</div>
					<?php endif; ?>
					
				</div>


			</div>

		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>