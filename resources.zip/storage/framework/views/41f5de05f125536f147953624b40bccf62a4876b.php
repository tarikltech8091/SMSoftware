<?php $__env->startSection('content'); ?>
<!-- <div class="row"> -->

<div class="row">

	<div class="col-md-4">
		<div class="thumbnail thumb-border">
			<div onclick="location.href='http://www.ndub.edu.bd/';" class="icon-size">
				<center><i class="fa fa-university" aria-hidden="true"></i></center>
			</div>
			<div onclick="location.href='http://www.ndub.edu.bd/';" class="form_name">
				<center><h3>University</h3></center>
			</div>
		</div>
	</div>

	<div class="col-md-4">
		<div class="thumbnail thumb-border">
			<div onclick="location.href='<?php echo e(url('/online-application')); ?>';" class="icon-size">
				<center><i class="fa fa-file-text-o" aria-hidden="true"></i></center>
			</div>
			<div onclick="location.href='<?php echo e(url('/online-application')); ?>';" class="form_name">
				<center><h3>Online Application</h3></center>
			</div>
		</div>
	</div>

	<div class="col-md-4">
		<div class="thumbnail thumb-border">
			<div onclick="location.href='<?php echo e(url('/login')); ?>';" class="icon-size">
				<center><i class="fa fa-home"  aria-hidden="true"></i></center>
			</div>
			<div onclick="location.href='<?php echo e(url('/login')); ?>';"  class="form_name">
				<center><h3>Dashboard</h3></center>
			</div>
		</div>	
	</div>
	</div>

<!-- </div> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('application.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>