<!DOCTYPE HTML>
<html>
<head>
	<title><?php echo e(isset($page_title) ? $page_title: 'Sheet'); ?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />


	 <!-- Bootstrap Core CSS -->
	<link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel='stylesheet' type='text/css' />
	<!-- Custom CSS -->
	<link href="<?php echo e(asset('css/style.css')); ?>" rel='stylesheet' type='text/css' />
	<link href="<?php echo e(asset('css/excel.css')); ?>" rel='stylesheet' type='text/css' />
	<link href="<?php echo e(asset('css/bootstrap-datetimepicker.min.css')); ?>" rel='stylesheet' type='text/css' />
	<!-- Graph CSS -->
	<link href="<?php echo e(asset('css/font-awesome.css')); ?>" rel="stylesheet"> 
	<!-- jQuery -->
	<!-- lined-icons -->
	<link rel="stylesheet" href="<?php echo e(asset('css/icon-font.min.css')); ?>" type='text/css' />
	<link rel="shortcut icon" href="<?php echo e(asset('fav.png')); ?>">


<!-- Placed js at the end of the document so the pages load faster -->
</head> 
<body>


	<div class="container">
		<?php echo $__env->yieldContent('content'); ?>
	</div>
		

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo e(asset('js/jquery-1.12.3.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
</body>
</html>
