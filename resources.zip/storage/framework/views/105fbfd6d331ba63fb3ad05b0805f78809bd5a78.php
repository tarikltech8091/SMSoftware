 
 <?php $__env->startSection('content'); ?>
 <?php echo $__env->make('layout.bradecrumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
 <div class="row page_row"><!--message-->
 	<div class="col-md-12">
 		<!--error message*******************************************-->
 		<?php if($errors->count() > 0 ): ?>

 		<div class="alert alert-danger">
 			<h6>The following errors have occurred:</h6>
 			<ul>
 				<?php foreach( $errors->all() as $message ): ?>
 				<li><?php echo e($message); ?></li>
 				<?php endforeach; ?>
 			</ul>
 		</div>
 		<?php endif; ?>
 		
 		<?php if(Session::has('message')): ?>
 		<div class="alert alert-success" role="alert">
 			<?php echo e(Session::get('message')); ?>

 		</div> 
 		<?php endif; ?>

 		<?php if(Session::has('errormessage')): ?>
 		<div class="alert alert-danger" role="alert">
 			<?php echo e(Session::get('errormessage')); ?>

 		</div>
 		<?php endif; ?>
 		<!--*******************************End of error message*************************************-->
 	</div>
 </div><!--/message-->

 <div class="row page_row">
 	<div class="col-md-12">
 		<div class="panel panel-info">
 			<div class="panel-body">
 				<form action="<?php echo e(url('/faculty/notice-board/edit/'.$edit_faculty_notice->notice_tran_code)); ?>" method="post">
 					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

 					<?php 
 					$program_list =\App\Register::ProgramList();
 					?>
 					<div class="form-group">
 						<label for="Program">Program <span class="required-sign">*</span></label>
 						<select class="form-control" name="notice_program">
 							<option  value="all">All</option>
 							<?php if(!empty($program_list)): ?>
 							<?php foreach($program_list as $key => $list): ?>
 							<option <?php echo e(($edit_faculty_notice->notice_program == $list->program_id) ? "selected" :''); ?> 
 								value="<?php echo e($list->program_id); ?>"><?php echo e($list->program_title); ?></option>
 								<?php endforeach; ?>
 								<?php endif; ?>
 							</select> 
 						</div>

 						<?php
 						$faculty_id=\Auth::user()->user_id;
 						$select_course=\DB::table('faculty_assingned_course')
 						->where('assigned_course_faculties','like',$faculty_id)
 						->get();
 						?>
 						<div class="form-group">
 							<label for="Course">Course <span class="required-sign">*</span></label>
 							<select  name="notice_to" class="form-control" required>
 								<option  value="all">All</option>
 								<?php if(!empty($select_course)): ?>
 								<?php foreach($select_course as $key => $list): ?>
 								<option <?php echo e(($edit_faculty_notice->notice_to == $list->assigned_course_id) ? "selected" :''); ?> value="<?php echo e($list->assigned_course_id); ?>"><?php echo e($list->assigned_course_title); ?></option>
 								<?php endforeach; ?>
 								<?php endif; ?>

 							</select>
 						</div>

 						<div class="form-group">
 							<label>Title</label>
 							<input type="text" name="notice_subject" class="form-control" value="<?php echo e($edit_faculty_notice->notice_subject); ?>" />
 						</div>

 						<div class="form-group">
 							<label>Description</label>
 							<textarea name="notice_message" rows="10" class="form-control" value="" id="noticeboard"><?php echo e($edit_faculty_notice->notice_message); ?></textarea>
 						</div>

 						<div class="modal-footer">
 							<a href="<?php echo e(url('/faculty/notice-board')); ?>" class="btn btn-danger" data-toggle="tooltip" title="Cancel Edit">Cancel</a>
 							<input type="submit" class="btn btn-success" value="Update" data-toggle="tooltip" title="Update Notice">
 						</div>
 					</form>
 				</div>
 			</div>
 		</div>
 	</div>

 	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>