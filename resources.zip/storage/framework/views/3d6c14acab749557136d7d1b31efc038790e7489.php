<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layout.bradecrumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--error message*******************************************-->
<div class="row page_row">
	<div class="col-md-12">
		<?php if($errors->count() > 0 ): ?>

		<div class="alert alert-danger">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<h6>The following errors have occurred:</h6>
			<ul>
				<?php foreach( $errors->all() as $message ): ?>
				<li><?php echo e($message); ?></li>
				<?php endforeach; ?>
			</ul>
		</div>
		<?php endif; ?>

		<?php if(Session::has('message')): ?>
		<div class="alert alert-success" role="alert">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<?php echo e(Session::get('message')); ?>

		</div> 
		<?php endif; ?>

		<?php if(Session::has('errormessage')): ?>
		<div class="alert alert-danger" role="alert">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<?php echo e(Session::get('errormessage')); ?>

		</div>
		<?php endif; ?>

	</div>
</div>
<!--end of error message*************************************-->

<div class="row page_row">
	<div class="col-md-12">
		<div class="panel panel-body padding_0">
			<div class="sorting_form"><!--header inline form-->
			<form method="get" action="<?php echo e(url('/accounts/student/payment/summery')); ?>" enctype="multipart/form-data">
				<?php 
				$program_list =\App\Applicant::ProgramList();

				?>
				<div class="form-group col-md-6">
					<label for="Program">Program</label>
					<select class="form-control program" name="program" >
						<option value="0">All</option>
						<?php if(!empty($program_list)): ?>
						<?php foreach($program_list as $key => $list): ?>
						<option <?php echo e((isset($_GET['program']) && ($list->program_id==$_GET['program'])) ? 'selected':''); ?> value="<?php echo e($list->program_id); ?>"><?php echo e($list->program_title); ?></option>
						<?php endforeach; ?>
						<?php endif; ?>
					</select>
				</div>


				<div class="form-group col-md-4">
					<label for="AcademicYear">Batch</label>
					<select class="form-control " name="batch_no" >
						<option value="0">All</option>
						<?php if(!empty($batch_list)): ?>
						<?php foreach($batch_list as $key => $list): ?>
						<option <?php echo e((isset($_GET['batch_no']) && ($list->batch_no == $_GET['batch_no'])) ? 'selected':''); ?> value="<?php echo e($list->batch_no); ?>"><?php echo e($list->batch_no); ?></option>
						<?php endforeach; ?>
						<?php endif; ?>
					</select>
				</div>

				<div class="form-group col-md-1" style="margin-top:20px;">
					<button class="btn btn-danger total_registered_student_search" data-toggle="tooltip" title="Search Students">Serach</button>
				</div>
			</form>
			<?php if(isset($_GET['program']) && isset($_GET['batch_no'])): ?>
				<div class="col-md-1 margin_top_20">
					<span class="btn btn-warning" data-toggle="tooltip" title="Download Student Payment Summery List"><a href="<?php echo e(url('/accounts/student/payment/summery/excel/program-'.$_GET['program'].'/batch-'.$_GET['batch_no'])); ?>"> <i class="fa fa-print"></i></a></span>
				</div>
			<?php endif; ?>
			</div>
		</div><!--/header inline form-->
	</div>



	<div class="page_row">

		<div class="col-md-12">
			<div class="panel panel-info">
				<div class="panel-heading">Sutdent List</div>
				<div class="panel-body"><!--info body-->

					<?php if(!empty($all_student_payment_summery_info)): ?>
					<table class="table table-hover table-bordered">
						<thead>
							<tr>
								<th>SL</th>
								<th>Student ID</th>
								<th>Student Name</th>
								<th>Program</th>
								<th>Mobile</th>
								<th>Email</th>
								<th>Total Receiable</th>
								<th>Total Receiable Paid</th>
								<th>Others Paid</th>
								<th>Due</th>
							</tr>
						</thead>
						<tbody>

							<?php foreach($all_student_payment_summery_info as $key => $list): ?>
							<?php 
								$student_details=unserialize($list); 
							?>
							<tr>

								<td><?php echo e($key+1); ?></td>
								<td><?php echo e($student_details[0]); ?></td>
								<td><?php echo e($student_details[1]); ?></td>
								<td><?php echo e($student_details[2]); ?></td>
								<td><?php echo e($student_details[3]); ?></td>
								<td><?php echo e($student_details[4]); ?></td>
								<td><?php echo e($student_details[5]); ?></td>
								<td><?php echo e($student_details[6]); ?></td>
								<td><?php echo e($student_details[7]); ?></td>
								<td><?php echo e($student_details[8]); ?></td>
							</tr>
							<?php endforeach; ?>

						</tbody>
					</table>
					<?php else: ?>
					<div class="alert alert-success">
						<center><h3 style="font-style:italic">No Data Found !</h3></center>
					</div>
					<?php endif; ?>
				</div><!--/info body-->
			</div>
		</div>
		
	</div>

</div>
<input type="hidden" name="current_page_url" class="current_page_url" value="<?php echo e(\Request::fullUrl()); ?>">
<input type="hidden" name="site_url" class="site_url" value="<?php echo e(url('/')); ?>">

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>