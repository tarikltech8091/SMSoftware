<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layout.bradecrumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--error message*******************************************-->
<div class="row page_row">
	<div class="col-md-12">
		<?php if($errors->count() > 0 ): ?>

		<div class="alert alert-danger">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<h6>The following errors have occurred:</h6>
			<ul>
				<?php foreach( $errors->all() as $message ): ?>
				<li><?php echo e($message); ?></li>
				<?php endforeach; ?>
			</ul>
		</div>
		<?php endif; ?>

		<?php if(Session::has('message')): ?>
		<div class="alert alert-success" role="alert">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<?php echo e(Session::get('message')); ?>

		</div> 
		<?php endif; ?>

		<?php if(Session::has('errormessage')): ?>
		<div class="alert alert-danger" role="alert">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<?php echo e(Session::get('errormessage')); ?>

		</div>
		<?php endif; ?>

	</div>
</div>
<!--end of error message*************************************-->

<div class="row page_row">
	<div class="col-md-12">
		<div class="col-md-12 alert alert-success dash_pad_0">

			<div class="row page_row_dash">

				<div class="col-md-2"><!--reprtcard-->
					<div class="report_view reprt_color_1 cursor dashborad_menus centered" onclick="location.href='<?php echo e(url('/register/applicant/list')); ?>';">
						<p>	
							<a href="<?php echo e(url('/register/applicant/list')); ?>"><i class="fa fa-list" aria-hidden="true"></i>
							</a>
						</p>
						<p class="report_name">	
							<a href="<?php echo e(url('/register/applicant/list')); ?>">Applicant List</a>
						</p>
					</div>
				</div><!--/reprtcard-->

				<div class="col-md-2"><!--reprtcard-->
					<div class="report_view reprt_color_1 cursor dashborad_menus" onclick="location.href='<?php echo e(url('/register/admission/list')); ?>';">
						<p>	
							<a href="<?php echo e(url('/register/admission/list')); ?>"><i class="fa fa-list-alt" aria-hidden="true"></i>
							</a>
						</p>
						<p class="report_name">	
							<a href="<?php echo e(url('/register/admission/list')); ?>">Admmission List</a>
						</p>
					</div>
				</div><!--/reprtcard-->

				<div class="col-md-2"><!--reprtcard-->
					<div class="report_view reprt_color_1 cursor dashborad_menus" onclick="location.href='<?php echo e(url('/register/admission/confirm')); ?>';">
						<p>	
							<a href="<?php echo e(url('/register/admission/confirm')); ?>"><i class="fa fa-check-square-o" aria-hidden="true"></i>
							</a>
						</p>
						<p class="report_name">	
							<a href="<?php echo e(url('/register/admission/confirm')); ?>">Admmission Confirm</a>
						</p>
					</div>
				</div><!--/reprtcard-->


				<div class="col-md-2"><!--reprtcard-->
					<div class="report_view reprt_color_1 cursor dashborad_menus" onclick="location.href='<?php echo e(url('/register/student/credit/transfer')); ?>';">
						<p>	
							<a href="<?php echo e(url('/register/student/credit/transfer')); ?>"><i class="fa fa-exchange" aria-hidden="true"></i></a>
						</p>
						<p class="report_name">	
							<a href="<?php echo e(url('/register/student/credit/transfer')); ?>">Student Credit Transfer</a>
						</p>
					</div>
				</div><!--/reprtcard-->


				<div class="col-md-2"><!--reprtcard-->
					<div class="report_view reprt_color_1 cursor dashborad_menus" onclick="location.href='<?php echo e(url('/register/faculty-account-registration')); ?>';">
						<p>	
							<a href="<?php echo e(url('/register/faculty-account-registration')); ?>"><i class="fa fa-user-plus" aria-hidden="true"></i>
							</a>
						</p>
						<p class="report_name">	
							<a href="<?php echo e(url('/register/faculty-account-registration')); ?>">Faculty Registration</a>
						</p>
					</div>
				</div><!--/reprtcard-->

				<div class="col-md-2"><!--reprtcard-->
					<div class="report_view reprt_color_1 cursor dashborad_menus" onclick="location.href='<?php echo e(url('/register/employee-registration')); ?>';">
						<p>	
							<a href="<?php echo e(url('/register/employee-registration')); ?>"><i class="fa fa-user-plus" aria-hidden="true"></i>
							</a>
						</p>
						<p class="report_name">	
							<a href="<?php echo e(url('/register/employee-registration')); ?>">Employee Registration</a>
						</p>
					</div>
				</div><!--/reprtcard-->

			</div>


			<div class="row page_row_dash">


				<div class="col-md-2"><!--reprtcard-->
					<div class="report_view reprt_color_1 cursor dashborad_menus" onclick="location.href='<?php echo e(url('/register/notice-board')); ?>';">
						<p>	
							<a href="<?php echo e(url('/register/notice-board')); ?>"><i class='fa fa-th-large'></i></a>
						</p>
						<p class="report_name">	
							<a href="<?php echo e(url('/register/notice-board')); ?>">Notice Board</a>
						</p>
					</div>
				</div><!--/reprtcard-->

				<div class="col-md-2"><!--reprtcard-->
					<div class="report_view reprt_color_1 cursor dashborad_menus" onclick="location.href='<?php echo e(url('/register/class-teacher-assign')); ?>';">
						<p>	
							<a href="<?php echo e(url('/register/class-teacher-assign')); ?>"><i class="fa fa-user" aria-hidden="true"></i>
							</a>
						</p>
						<p class="report_name">	
							<a href="<?php echo e(url('/register/class-teacher-assign')); ?>">Class Teacher Assign</a>
						</p>
					</div>
				</div><!--/reprtcard-->

				<div class="col-md-2"><!--reprtcard-->
					<div class="report_view reprt_color_1 cursor dashborad_menus" onclick="location.href='<?php echo e(url('/register/faculty-assigned-course')); ?>';">
						<p>	
							<a href="<?php echo e(url('/register/faculty-assigned-course')); ?>"><i class="fa fa-book" aria-hidden="true"></i>
							</a>
						</p>
						<p class="report_name">	
							<a href="<?php echo e(url('/register/faculty-assigned-course')); ?>">Faculty Course Assign</a>
						</p>
					</div>
				</div><!--/reprtcard-->


				<div class="col-md-2"><!--reprtcard-->
					<div class="report_view reprt_color_1 cursor dashborad_menus" onclick="location.href='<?php echo e(url('/register/trimester-student-assign')); ?>';">
						<p>	
							<a href="<?php echo e(url('/register/trimester-student-assign')); ?>"><i class='fa fa-th-large'></i></a>
						</p>
						<p class="report_name">	
							<a href="<?php echo e(url('/register/trimester-student-assign')); ?>">Trimester Student Assign</a>
						</p>
					</div>
				</div><!--/reprtcard-->

				<div class="col-md-2"><!--reprtcard-->
					<div class="report_view reprt_color_1 cursor dashborad_menus" onclick="location.href='<?php echo e(url('/register/student/attendance/list')); ?>';">
						<p>	
							<a href="<?php echo e(url('/register/student/attendance/list')); ?>"><i class="fa fa-list-ol" aria-hidden="true"></i></a>
						</p>
						<p class="report_name">	
							<a href="<?php echo e(url('/register/student/attendance/list')); ?>">Student Class Attendance</a>
						</p>
					</div>
				</div><!--/reprtcard-->


				<div class="col-md-2"><!--reprtcard-->
					<div class="report_view reprt_color_1 cursor dashborad_menus" onclick="location.href='<?php echo e(url('/register/student/withdraw/course')); ?>';">
						<p>	
							<a href="<?php echo e(url('/register/student/withdraw/course')); ?>"><i class="fa fa-minus-square" aria-hidden="true"></i></a>
						</p>
						<p class="report_name">	
							<a href="<?php echo e(url('/register/student/withdraw/course')); ?>">Student Course Withdraw</a>
						</p>
					</div>
				</div><!--/reprtcard-->


			</div>

			<?php if((\Auth::user()->user_type) == 'register' && (\Auth::user()->user_role) == 'head'): ?>

				<div class="row page_row_dash">

					<div class="col-md-2"><!--reprtcard-->
						<div class="report_view reprt_color_1 cursor dashborad_menus" onclick="location.href='<?php echo e(url('/register/academic-calender-registration')); ?>';">
							<p>	
								<a href="<?php echo e(url('/register/academic-calender-registration')); ?>"><i class="fa fa-calendar" aria-hidden="true"></i>
								</a>
							</p>
							<p class="report_name">	
								<a href="<?php echo e(url('/register/academic-calender-registration')); ?>" >Academic Calender</a>
							</p>
						</div>
					</div><!--/reprtcard-->


					<div class="col-md-2"><!--reprtcard-->
						<div class="report_view reprt_color_1 cursor dashborad_menus" onclick="location.href='<?php echo e(url('/register/student-grade-equivalent')); ?>';">
							<p>	
								<a href="<?php echo e(url('/register/student-grade-equivalent')); ?>"><i class='fa fa-exchange'></i></a>
							</p>
							<p class="report_name">	
								<a href="<?php echo e(url('/register/student-grade-equivalent')); ?>">Academic Grading System</a>
							</p>
						</div>
					</div><!--/reprtcard-->


					<div class="col-md-2"><!--reprtcard-->
						<div class="report_view reprt_color_1 cursor dashborad_menus" onclick="location.href='<?php echo e(url('/register/account-summery')); ?>';">
							<p>	
								<a href="<?php echo e(url('/register/account-summery')); ?>"><i class="fa fa-money" aria-hidden="true"></i></a>
							</p>
							<p class="report_name">	
								<a href="<?php echo e(url('/register/account-summery')); ?>">Account Summery</a>
							</p>
						</div>
					</div><!--/reprtcard-->

					<div class="col-md-2"><!--reprtcard-->
						<div class="report_view reprt_color_1 cursor dashborad_menus" onclick="location.href='<?php echo e(url('/register/student-list')); ?>';">
							<p>	
								<a href="<?php echo e(url('/register/student-list')); ?>"><i class="fa fa-list" aria-hidden="true"></i>
								</a>
							</p>
							<p class="report_name">	
								<a href="<?php echo e(url('/register/student-list')); ?>">Student List</a>
							</p>
						</div>
					</div><!--/reprtcard-->

					<div class="col-md-2"><!--reprtcard-->
						<div class="report_view reprt_color_1 cursor dashborad_menus" onclick="location.href='<?php echo e(url('/register/faculty-list')); ?>';">
							<p>	
								<a href="<?php echo e(url('/register/faculty-list')); ?>"><i class="fa fa-list" aria-hidden="true"></i></a>
							</p>
							<p class="report_name">	
								<a href="<?php echo e(url('/register/faculty-list')); ?>">Faculty List</a>
							</p>
						</div>
					</div><!--/reprtcard-->

					<div class="col-md-2"><!--reprtcard-->
						<div class="report_view reprt_color_1 cursor dashborad_menus" onclick="location.href='<?php echo e(url('/register/employee-list')); ?>';">
							<p>	
								<a href="<?php echo e(url('/register/employee-list')); ?>"><i class="fa fa-list" aria-hidden="true"></i></a>
							</p>
							<p class="report_name">	
								<a href="<?php echo e(url('/register/employee-list')); ?>">Employee List</a>
							</p>
						</div>
					</div><!--/reprtcard-->

				</div>
			<?php endif; ?>


			<div class="row page_row_dash">

				<div class="col-md-2"><!--reprtcard-->
					<div class="report_view reprt_color_1 cursor dashborad_menus" onclick="location.href='<?php echo e(url('/register/student/grade-sheet')); ?>';">
						<p>	
							<a href="<?php echo e(url('/register/student/grade-sheet')); ?>"><i class="fa fa-graduation-cap" aria-hidden="true"></i></a>
						</p>
						<p class="report_name">	
							<a href="<?php echo e(url('/register/student/grade-sheet')); ?>">Register Student Grade Sheet</a>
						</p>
					</div>
				</div><!--/reprtcard-->


				<div class="col-md-2"><!--reprtcard-->
					<div class="report_view reprt_color_1 cursor dashborad_menus" onclick="location.href='<?php echo e(url('/register/all-summery')); ?>';">
						<p>	
							<a href="<?php echo e(url('/register/all-summery')); ?>"><i class="fa fa-list-alt" aria-hidden="true"></i></a>
						</p>
						<p class="report_name">	
							<a href="<?php echo e(url('/register/all-summery')); ?>">Register All Summery</a>
						</p>
					</div>
				</div><!--/reprtcard-->

				<div class="col-md-2"><!--reprtcard-->
					<div class="report_view reprt_color_1 cursor dashborad_menus" onclick="location.href='<?php echo e(url('/register/univ-time-slot')); ?>';">
						<p>	
							<a href="<?php echo e(url('/register/univ-time-slot')); ?>"><i class="fa fa-clock-o" aria-hidden="true"></i></a>
						</p>
						<p class="report_name">	
							<a href="<?php echo e(url('/register/univ-time-slot')); ?>">Time Slot</a>
						</p>
					</div>
				</div><!--/reprtcard-->

				<div class="col-md-2"><!--reprtcard-->
					<div class="report_view reprt_color_1 cursor dashborad_menus" onclick="location.href='<?php echo e(url('/register/class-schedule')); ?>';">
						<p>	
							<a href="<?php echo e(url('/register/class-schedule')); ?>"><i class="fa fa-clock-o" aria-hidden="true"></i></a>
						</p>
						<p class="report_name">	
							<a href="<?php echo e(url('/register/class-schedule')); ?>">Class Schedule</a>
						</p>
					</div>
				</div><!--/reprtcard-->

				<div class="col-md-2"><!--reprtcard-->
					<div class="report_view reprt_color_1 cursor dashborad_menus" onclick="location.href='<?php echo e(url('/register/schedule/exam-schedule')); ?>';">
						<p>	
							<a href="<?php echo e(url('/register/schedule/exam-schedule')); ?>"><i class="fa fa-clock-o" aria-hidden="true"></i></a>
						</p>
						<p class="report_name">	
							<a href="<?php echo e(url('/register/schedule/exam-schedule')); ?>">Exam Schedule</a>
						</p>
					</div>
				</div><!--/reprtcard-->

				<div class="col-md-2"><!--reprtcard-->
					<div class="report_view reprt_color_1 cursor dashborad_menus" onclick="location.href='<?php echo e(url('/register/attendance/percent')); ?>';">
						<p>	
							<a href="<?php echo e(url('/register/attendance/percent')); ?>"><i class="fa fa-percent" aria-hidden="true"></i></a>
						</p>
						<p class="report_name">	
							<a href="<?php echo e(url('/register/attendance/percent')); ?>">Student Attendance</a>
						</p>
					</div>
				</div><!--/reprtcard-->


			</div>

			<div class="row page_row_dash">

							
				<div class="col-md-2"><!--reprtcard-->
					<div class="report_view reprt_color_1 cursor dashborad_menus" onclick="location.href='<?php echo e(url('/register/student/booking/supplimentry/course')); ?>';">
						<p>	
							<a href="<?php echo e(url('/register/student/booking/supplimentry/course')); ?>"><i class="fa fa-book" aria-hidden="true"></i></a>
						</p>
						<p class="report_name">	
							<a href="<?php echo e(url('/register/student/booking/supplimentry/course')); ?>">Supplimentry Booking Course</a>
						</p>
					</div>
				</div><!--/reprtcard-->				

				<div class="col-md-2"><!--reprtcard-->
					<div class="report_view reprt_color_1 cursor dashborad_menus" onclick="location.href='<?php echo e(url('/register/student/booking/supplimentry/course/list')); ?>';">
						<p>	
							<a href="<?php echo e(url('/register/student/booking/supplimentry/course/list')); ?>"><i class="fa fa-list-alt" aria-hidden="true"></i></a>
						</p>
						<p class="report_name">	
							<a href="<?php echo e(url('/register/student/booking/supplimentry/course/list')); ?>">Supplimentry Booking List </a>
						</p>
					</div>
				</div><!--/reprtcard-->

				<div class="col-md-2"><!--reprtcard-->
					<div class="report_view reprt_color_1 cursor dashborad_menus" onclick="location.href='<?php echo e(url('/register/student/supplimentry/course')); ?>';">
						<p>	
							<a href="<?php echo e(url('/register/student/supplimentry/course')); ?>"><i class="fa fa-book" aria-hidden="true"></i></a>
						</p>
						<p class="report_name">	
							<a href="<?php echo e(url('/register/student/supplimentry/course')); ?>">Supplimentry Course</a>
						</p>
					</div>
				</div><!--/reprtcard-->

				<div class="col-md-2"><!--reprtcard-->
					<div class="report_view reprt_color_1 cursor dashborad_menus" onclick="location.href='<?php echo e(url('/register/block/student-list')); ?>';">
						<p>	
							<a href="<?php echo e(url('/register/block/student-list')); ?>"><i class="fa fa-ban" aria-hidden="true"></i></a>
						</p>
						<p class="report_name">	
							<a href="<?php echo e(url('/register/block/student-list')); ?>">Block Student List</a>
						</p>
					</div>
				</div><!--/reprtcard-->

			</div>



		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>