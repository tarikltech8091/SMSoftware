<?php $__env->startSection('content'); ?>
<style type="text/css">
	.texting{
		background-color: #19a15f;
		border: 1px solid;
	}
	.heading{
		text-align: center;
		font-weight: bolder;
		background-color: #92cddc;
		border: 1px solid;
		color: #000;
		font-size: 18px;
	}

	
</style>
<table class="table table-striped table-bordered table-hover applicant_register">
	<thead>

		<tr>
			<th class="heading" colspan="7">FACULTY LIST</th>					
		</tr>
		<tr>
			<th>SL No.</th>
			<th>Faculty ID</th>
			<th>Faculty Name</th>
			<th>Department</th>
			<th>Program</th>
			<th>Joining Date</th>
			<th>Mobile</th>
			<th>Email</th>
			
		</tr>
	</thead>
	<tbody>
		<?php if(count($faculty_list)>0): ?>
		
		<?php foreach($faculty_list as $key => $list): ?>
		
		<tr>
			<td ><?php echo e(($key+1)); ?></td>
			<td ><?php echo e($list->faculty_id); ?></td>
			<td><?php echo e($list->first_name); ?> <?php echo e($list->middle_name); ?> <?php echo e($list->last_name); ?></td>
			<td><?php echo e($list->department_title); ?></td>
			<td><?php echo e($list->program_code); ?></td>
			<td><?php echo e($list->faculty_join_date); ?></td>
			<td><?php echo e($list->mobile); ?></td>
			<td><?php echo e($list->email); ?></td>
		</tr>

		<?php endforeach; ?>
		<?php else: ?>
		<tr class="text-center">
			<td colspan="8">No Data available</td>
		</tr>
		
		<?php endif; ?>
	</tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('excelsheet.layout.master-excel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>