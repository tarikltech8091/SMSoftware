

<?php if(!empty($course_list)): ?>

<option value="0">Select Course</option>
<?php foreach($course_list as $key => $list): ?>
<option value="<?php echo e($list->course_code); ?>"><?php echo e($list->course_code); ?> <?php echo e($list->course_title); ?></option>
<?php endforeach; ?>
<?php else: ?>
<option value="0">No Course</option>

<?php endif; ?>


