<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layout.bradecrumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--error message*******************************************-->
<div class="row page_row">
	<div class="col-md-12">
		<?php if($errors->count() > 0 ): ?>

		<div class="alert alert-danger">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<h6>The following errors have occurred:</h6>
			<ul>
				<?php foreach( $errors->all() as $message ): ?>
				<li><?php echo e($message); ?></li>
				<?php endforeach; ?>
			</ul>
		</div>
		<?php endif; ?>

		<?php if(Session::has('message')): ?>
		<div class="alert alert-success" role="alert">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<?php echo e(Session::get('message')); ?>

		</div> 
		<?php endif; ?>

		<?php if(Session::has('errormessage')): ?>
		<div class="alert alert-danger" role="alert">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<?php echo e(Session::get('errormessage')); ?>

		</div>
		<?php endif; ?>

	</div>
</div>
<!--end of error message*************************************-->

<div class="row page_row">
	<div class="col-md-12">
		<div class="panel panel-body padding_0">
			<div class=" sorting_form"><!--header inline form-->
				<div class="form-group col-md-4">
					<label >Employee Department</label>
					<select class="form-control employee_department" name="employee_department">
						<option value="0">All</option>
						<option <?php echo e(isset($_GET['employee_department']) && ($_GET['employee_department']=='accounts') ? 'selected' : ''); ?> value="accounts">Account Office</option>
						<option <?php echo e(isset($_GET['employee_department']) && ($_GET['employee_department']=='register') ? 'selected' : ''); ?> value="register">Register Office</option>
						<option <?php echo e(isset($_GET['employee_department']) && ($_GET['employee_department']=='department') ? 'selected' : ''); ?> value="department">Department Office</option>
						<option <?php echo e(isset($_GET['employee_department']) && ($_GET['employee_department']=='stuff') ? 'selected' : ''); ?> value="stuff">Stuff</option>
					</select>

				</div>

				<div class="form-group col-md-1" style="margin-top:20px;">
					<button class="btn btn-danger employee_search" data-toggle="tooltip" title="Search Employee List">Serach</button>
				</div>
				<div class="col-md-1 margin_top_20">
					<span class="btn btn-warning register_employee_list_print" data-toggle="tooltip" title="Download Employee List"><i class="fa fa-print"></i></span>
				</div>

			</div>
		</div><!--/header inline form-->
	</div>



	<div class="page_row">

		<div class="col-md-12">
			<div class="panel panel-info">
				<div class="panel-heading">Employee List</div>
				<div class="panel-body"><!--info body-->

					<?php if(!empty($employee_list)): ?>
					<table class="table table-hover table-bordered">
						<thead>
							<tr>
								<th>SL</th>
								<th>Employee ID</th>
								<th>Employee Name</th>
								<th>Employee Department</th>
								<th>Designation</th>
								<th>Joining Date</th>
								<th>Mobile</th>
								<th>Email</th>
							</tr>
						</thead>
						<tbody>

							<?php foreach($employee_list as $key => $list): ?>
							<tr>
								<td><?php echo e($key+1); ?></td>
								<td><?php echo e($list->employee_id); ?></td>
								<td><?php echo e($list->first_name); ?> <?php echo e($list->middle_name); ?> <?php echo e($list->last_name); ?></td>
								<td><?php echo e($list->pro_designation); ?></td>
								<td><?php echo e($list->employee_designation); ?></td>
								<td><?php echo e($list->employee_join_date); ?></td>
								<td><?php echo e($list->mobile); ?></td>
								<td><?php echo e($list->email); ?></td>
							</tr>
							<?php endforeach; ?>

						</tbody>
					</table>
					<?php else: ?>
					<div class="alert alert-success">
						<center><h3 style="font-style:italic">No Data Found !</h3></center>
					</div>
					<?php endif; ?>
				</div><!--/info body-->
			</div>
		</div>
		
	</div>

</div>
<input type="hidden" name="current_page_url" class="current_page_url" value="<?php echo e(\Request::fullUrl()); ?>">
<input type="hidden" name="site_url" class="site_url" value="<?php echo e(url('/')); ?>">

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>