<?php $__env->startSection('content'); ?>
<style type="text/css">
	.texting{
		background-color: #19a15f;
		border: 1px solid;
	}
	.heading{
		text-align: center;
		font-weight: bolder;
		background-color: #92cddc;
		border: 1px solid;
		color: #000;
		font-size: 18px;
	}

	
</style>
<table class="table table-striped table-bordered table-hover applicant_register">
	<thead>

		<tr>
			<th class="heading" colspan="7">ACCOUNTS STUDENT PAYMENT LIST</th>					
		</tr>
		<tr>
			<th>SL No.</th>
			<th>Student ID</th>
			<th>Program</th>
			<th>Trimester</th>
			<th>Year</th>
			<th>Fee Type</th>
			<th>Receive Type</th>
			<th>Amount</th>
			<th>Created By</th>
			<th>Created At</th>
			
		</tr>
	</thead>
	<tbody>

		<?php if(!empty($student_payment_transaction_detail) && count($student_payment_transaction_detail)>0): ?>
		<?php foreach($student_payment_transaction_detail as $key => $list): ?>
		<tr>
			<td><?php echo e($key+1); ?></td>
			<td><?php echo e($list->payment_student_serial_no); ?></td>
			<td><?php echo e($list->program_code); ?></td>
			<td><?php echo e($list->semester_title); ?></td>
			<td><?php echo e($list->payment_year); ?></td>
			<td><?php echo e(($list->fee_category_name)? ($list->fee_category_name) : 'Others Fee'); ?></td>
			<td><?php echo e($list->payment_receive_type); ?></td>
			<td><?php echo e($list->payment_amounts); ?></td>
			<td><?php echo e($list->updated_by); ?></td>
			<td><?php echo e($list->updated_at); ?></td>
		</tr>
		<?php endforeach; ?>
		<tr></tr>
		<tr></tr>
		<tr>
			<th colspan="7" align="center">Total Amount</th>
			<th colspan="3"><?php echo e(isset($total_amount)? $total_amount :0); ?></th>
		</tr>
		<?php else: ?>
		<tr>
			<td colspan="10" align="center">No Data Found !</td>
		</tr>
		<?php endif; ?>
	</tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('excelsheet.layout.master-excel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>