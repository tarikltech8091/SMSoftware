<?php if(!empty($student_list)): ?>
	<option value="0">Select Student</option>
	<?php foreach($student_list as $key => $list): ?>
		<option <?php echo e((isset($_GET['student_no']) && ($_GET['student_no'] == $list->student_serial_no)) ? 'selected' : ''); ?> value="<?php echo e($list->student_serial_no); ?>"><?php echo e($list->student_serial_no); ?></option>
	<?php endforeach; ?>
<?php else: ?>
	<option value="0">Select Student</option>
<?php endif; ?>
