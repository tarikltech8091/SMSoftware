<?php $__env->startSection('content'); ?>
<style type="text/css">
	.remember_me{
		border-radius: 3px;
		box-shadow: 0 0 4px 1px rgba(0, 0, 0, 0.08);
		background: #f9f9f9 none repeat scroll 0 0;
		width:22%;
		height:74px;
		border: 1px solid #d3d3d3;
	}

</style>
<div class="sign-in-form"><!--login form-->
	<div class="sign-in-form-top login_form">
		<!-- <p><span>Sign In to</span> <a href="index.html">Admin</a></p> -->
		<img src="<?php echo e(asset('images/banner.png')); ?>">
	</div>
	<div class="signin">
		<div class="col-md-12">
			<?php if($errors->count() > 0 ): ?>
			<div class="alert alert-danger alert-dismissible">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h6>The following errors have occurred:</h6>
				<ul>
					<?php foreach( $errors->all() as $message ): ?>
					<li><?php echo e($message); ?></li>
					<?php endforeach; ?>
				</ul>
			</div>
			<?php endif; ?>
			<?php if(Session::has('message')): ?>
			<div class="alert alert-success" role="alert">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				<?php echo e(Session::get('message')); ?>

			</div> 
			<?php endif; ?>

			<?php if(Session::has('errormessage')): ?>
			<div class="alert alert-danger" role="alert">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				<?php echo e(Session::get('errormessage')); ?>

			</div> 
			<?php endif; ?>
		</div>
	  	<form action="<?php echo e(url('/new/password')); ?>" method="post">
	  		<input type="hidden" name="user_id" value="<?php echo e($user_serial_no->user_id); ?>">
	  		<input type="hidden" name="token" value="<?php echo e($remember_token); ?>">
			<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
			<div class="log-input">
				<div class="col-md-12">
					<input type="password" name="password" placeholder="*****" class="form-control lock">
				</div>
			</div>
			<div class="log-input">
				<div class="col-md-12">
					<input  type="password" name="confirm_password" placeholder="*****" class="form-control lock">
				</div>
			</div>
			<center>
				<div class="row">
					<input type="submit" value="PASSWORD SUBMIT"  class="btn btn-primary">
				</div>
			</center>
		</form>	
	</div>
</div><!--/login form-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>