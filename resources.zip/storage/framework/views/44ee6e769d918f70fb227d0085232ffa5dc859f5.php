<?php $__env->startSection('content'); ?>
<style type="text/css">
	.texting{
		background-color: #19a15f;
		border: 1px solid;
	}
	.heading{
		text-align: center;
		font-weight: bolder;
		background-color: #92cddc;
		border: 1px solid;
		color: #000;
		font-size: 18px;
	}

	
</style>
<table class="table table-striped table-bordered table-hover applicant_register">
	<thead>

		<tr>
			<th class="heading" colspan="7">STUDENT LIST</th>					
		</tr>
		<tr>
			<th>SL</th>
			<th>Student ID</th>
			<th>Student Name</th>
			<th>Program</th>
			<th>Mobile</th>
			<th>Email</th>
			<th>Status</th>
		</tr>
	</thead>
	<tbody>
		<?php if(!empty($student_list) && count($student_list)>0): ?>
		
		<?php foreach($student_list as $key => $list): ?>
		
		<tr>
			<td ><?php echo e(($key+1)); ?></td>
			<td ><?php echo e($list->student_serial_no); ?></td>
			<td><?php echo e($list->first_name); ?> <?php echo e($list->middle_name); ?> <?php echo e($list->last_name); ?></td>
			<td><?php echo e($list->program_code); ?></td>
			<td><?php echo e($list->mobile); ?></td>
			<td><?php echo e($list->email); ?></td>
			<td>
				<?php if(($list->student_status) == '-5'): ?>
				Blocked
				<?php else: ?>
				Active
				<?php endif; ?>
			</td>
		</tr>

		<?php endforeach; ?>
		<?php else: ?>
		<tr class="text-center">
			<td colspan="7">No Data available</td>
		</tr>
		
		<?php endif; ?>
	</tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('excelsheet.layout.master-excel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>