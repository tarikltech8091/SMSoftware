<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layout.bradecrumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="row page_row">
	<div class="col-md-12">
		<!--error message*******************************************-->
		<?php if($errors->count() > 0 ): ?>

		<div class="alert alert-danger">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<h6>The following errors have occurred:</h6>
			<ul>
				<?php foreach( $errors->all() as $message ): ?>
				<li><?php echo e($message); ?></li>
				<?php endforeach; ?>
			</ul>
		</div>
		<?php endif; ?>

		<?php if(Session::has('message')): ?>
		<div class="alert alert-success" role="alert">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<?php echo e(Session::get('message')); ?>

		</div> 
		<?php endif; ?>

		<?php if(Session::has('errormessage')): ?>
		<div class="alert alert-danger" role="alert">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<?php echo e(Session::get('errormessage')); ?>

		</div>
		<?php endif; ?>

	</div>
</div>
<!--end of error message*************************************-->

<div class="row page_row">
	<div class="col-md-12">
		<div class="col-md-12 alert alert-success dash_pad_0">

			<div class="row page_row_dash">
				<div class="col-md-2"><!--reprtcard-->
					<div class="report_view reprt_color_1 cursor dashborad_menus centered" onclick="location.href='<?php echo e(url('/academic-settings/home')); ?>';">
						<p>	
							<a href="<?php echo e(url('/academic-settings/home')); ?>"><i class="fa fa-cog" aria-hidden="true"></i>
							</a>
						</p>
						<p class="report_name">	
							<a href="<?php echo e(url('/academic-settings/home')); ?>">Academic Settings</a>
						</p>
					</div>
				</div><!--/reprtcard-->
				<div class="col-md-2"><!--reprtcard-->
					<div class="report_view reprt_color_1 cursor dashborad_menus centered" onclick="location.href='<?php echo e(url('/academic/course-settings')); ?>';">
						<p>	
							<a href="<?php echo e(url('/academic/course-settings')); ?>"><i class="fa fa-sliders" aria-hidden="true"></i>
							</a>
						</p>
						<p class="report_name">	
							<a href="<?php echo e(url('/academic/course-settings')); ?>">Course Settings</a>
						</p>
					</div>
				</div><!--/reprtcard-->

			</div>

		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>