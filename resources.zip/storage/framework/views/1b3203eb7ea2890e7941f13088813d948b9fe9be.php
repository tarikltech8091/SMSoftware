<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layout.bradecrumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="row page_row">

	<div class="col-md-9">
		<div class="panel panel-info">
			<div class="panel-heading ">
				<?php echo e(isset($univ_academic_calender->semester_title) ? $univ_academic_calender->semester_title : ''); ?> <?php echo e(isset($univ_academic_calender->academic_calender_year) ? $univ_academic_calender->academic_calender_year : ''); ?>

				<span><a href="<?php echo e(url('/faculty/invigilator-schedule-download')); ?>" ><i class="fa fa-print" data-toggle="tooltip" title="Download Exam Schedule"></i></a></span>
			</div>
			<div class="panel-body"><!--info body-->
				<center><h4>Trimester Midterm Exam Invigilator</h4></center>
				<table id="" class="table table-striped table-bordered table-hover">
					<thead>
						<tr>
							<th>Date</th>
							<th>Time</th>
							<th>Exam Room</th>

						</tr>
					</thead>
					<tbody>
						<?php if(!empty($invigilator_list_mid)): ?>
						<?php foreach($invigilator_list_mid as $key => $list_mid): ?>
						<?php
						$invigilators_mid=explode(',', $list_mid->invigilators_ID);


						?>
						<?php foreach($invigilators_mid as $key => $invigilator_mid): ?> 
						<?php if($invigilator_mid==\Auth::user()->user_id): ?>
						<tr>
							<td><?php echo e($list_mid->invigilators_exam_date); ?></td>
							<td><?php echo e($list_mid->invigilators_exam_time_slot); ?></td>
							<td><?php echo e($list_mid->invigilators_exam_room); ?></td>
						</tr>
						<?php endif; ?>
						<?php endforeach; ?>
						
						<?php endforeach; ?>
						<?php else: ?>
						<tr>
							<td colspan="3">
								<div class="alert alert-success">
									<center><h3 style="font-style:italic">No Data Available !</h3></center>
								</div>
							</td>
						</tr>
						<?php endif; ?>

					</tbody>
				</table><br><br>

				<center><h4>Trimester Final Exam Invigilator</h4></center>
				<table id="" class="table table-striped table-bordered table-hover">
					<thead>
						<tr>
							<th>Date</th>
							<th>Time</th>
							<th>Exam Room</th>

						</tr>
					</thead>
					<tbody>
						<?php if(!empty($invigilator_list_final)): ?>
						<?php foreach($invigilator_list_final as $key => $list_final): ?>
						<?php
						$invigilators_final=explode(',', $list_final->invigilators_ID);


						?>
						<?php foreach($invigilators_final as $key => $invigilator_final): ?> 
						<?php if($invigilator_final==\Auth::user()->user_id): ?>
						<tr>
							<td><?php echo e($list_final->invigilators_exam_date); ?></td>
							<td><?php echo e($list_final->invigilators_exam_time_slot); ?></td>
							<td><?php echo e($list_final->invigilators_exam_room); ?></td>
						</tr>
						<?php endif; ?>
						<?php endforeach; ?>
						
						<?php endforeach; ?>
						<?php else: ?>
						<tr>
							<td colspan="3">
								<div class="alert alert-success">
									<center><h3 style="font-style:italic">No Data Available !</h3></center>
								</div>
							</td>
						</tr>
						<?php endif; ?>

					</tbody>
				</table>
			</div><!--/info body-->
		</div>
	</div>
	<!--sidebar widget-->
	<div class="col-md-3 schedule">
		<?php echo $__env->make('pages.faculty.faculty-notice', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</div>
	<!--/sidebar widget-->
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>