<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layout.bradecrumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="page_row row"><!--message-->
	<div class="col-md-12">
		<!--error message*******************************************-->
		<?php if($errors->count() > 0 ): ?>

		<div class="alert alert-danger">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<h6>The following errors have occurred:</h6>
			<ul>
				<?php foreach( $errors->all() as $message ): ?>
				<li><?php echo e($message); ?></li>
				<?php endforeach; ?>
			</ul>
		</div>
		<?php endif; ?>
		
		<?php if(Session::has('message')): ?>
		<div class="alert alert-success" role="alert">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<?php echo e(Session::get('message')); ?>

		</div> 
		<?php endif; ?>

		<?php if(Session::has('errormessage')): ?>
		<div class="alert alert-danger" role="alert">
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<?php echo e(Session::get('errormessage')); ?>

		</div>
		<?php endif; ?>
		<!--*******************************End of error message*************************************-->
	</div>
</div><!--/message-->


<div class="row page_row">
	<div class="col-md-9 course">
		<div class="panel panel-info">
			<div class="panel-body">

				<div class="form-group col-md-5">
					<label for="Semester">Trimester</label>

					<select class="form-control semester" name="semester" >
						<?php if(!empty($semester_list)): ?>
						<?php foreach($semester_list as $key => $semester): ?>
						<option <?php echo e(isset($_GET['semester']) && ($_GET['semester'] == $semester->semester_code) ? 'selected' : ''); ?>  value="<?php echo e($semester->semester_code); ?>"><?php echo e($semester->semester_title); ?></option>
						<?php endforeach; ?>
						<?php endif; ?>
					</select>
				</div>
				<div class="form-group col-md-5">
					<label for="AcademicYear">Academic Year</label>
					<select class="form-control academic_year" name="academic_year" >
						<?php if(!empty($univ_academic_calender)): ?>
						<?php foreach($univ_academic_calender as $key => $year_list): ?>
						<option <?php echo e(isset($_GET['academic_year']) && ($_GET['academic_year'] == $year_list->academic_calender_year) ? 'selected' : ''); ?> value="<?php echo e($year_list->academic_calender_year); ?>"><?php echo e($year_list->academic_calender_year); ?></option>
						<?php endforeach; ?>
						<?php endif; ?>
					</select>
				</div>
				
				<div class="form-group col-md-2" style="margin-top:27px;">
					<button type="submit" class="btn btn-primary student_result_search" data-toggle="tooltip" title="Search Academic Result">Serach</button>
				</div>


			</div>
		</div>

		<?php if(isset($_GET['semester']) && isset($_GET['academic_year'])): ?>
		<div class="panel panel-info">
			
			<div class="panel-heading text-center">
				<span class="text-left">Student ID : <?php echo e(isset($student_info) ? $student_info->student_serial_no : ''); ?></span>
				<span class="text-right">Name : <?php echo e(isset($student_info) ? $student_info->first_name : ''); ?> <?php echo e(isset($student_info) ? $student_info->middle_name : ''); ?> <?php echo e(isset($student_info) ? $student_info->last_name : ''); ?></span>
			</div>
			<div class="panel-body"><!--info body-->
				<div class='student_info'>
					<label>CGPA : <?php echo e(isset($student_cgpa)? number_format($student_cgpa, 2) : '0.00'); ?></label>
				</div>
				<div class='student_credit'>

					<label>Total Credit Earned : <?php echo e(isset($total_earned_credit)? $total_earned_credit : '0.0'); ?></label>
					<label>Total Credit Attempted : <?php echo e(isset($total_taken_credit)? $total_taken_credit : '0.0'); ?></label>
				</div>
				<div class="grade_sheet">

					<table id="" class="table table-striped ">
						<thead>
							<tr>
								<th class="tbl_caption" colspan="6">Trimester : <?php echo e(isset($semester_info->semester_title) ? $semester_info->semester_title : ''); ?> <?php echo e(isset($year) ? $year : ''); ?></th>
							</tr>
							<tr>
								<th>Course Code</th>
								<th>Course Title</th>
								<th>Course Credit</th>
								<th>Earned Credit</th>
								<th>Grade</th>
								<th>Points</th>
							</tr>
						</thead>
						<tbody>

							<?php if(!empty($student_result)): ?>
							<?php 
							$total_credit=0;
							$total_credit_earned=0;
							$total_point=0;
							?>
							<?php foreach($student_result as $key => $result): ?>
							<tr>
								<?php
								$total_credit=$total_credit+$result->tabulatation_credit_hours;
								$total_credit_earned=$total_credit_earned+$result->tabulation_credit_earned;
								$total_point=$total_point+($result->tabulation_credit_earned)*($result->tabulation_grade_point);
								?>
								<td><?php echo e($result->tabulation_course_id); ?></td>
								<td><?php echo e($result->tabulation_course_title); ?></td>
								<td><?php echo e($result->tabulatation_credit_hours); ?></td>
								<td><?php echo e($result->tabulation_credit_earned); ?></td>
								<td><?php echo e($result->tabulation_grade); ?></td>
								<td><?php echo e($result->tabulation_grade_point); ?></td>
							</tr>
							<?php endforeach; ?>
							

							
							<tr>
								<th colspan="2" class="text-center">Trimester Total</th>
								<th><?php echo e(isset($total_credit) ? $total_credit: ''); ?></th>
								<th><?php echo e(isset($total_credit_earned) ? $total_credit_earned: ''); ?></th>
								<th>GPA</th>
								<th><?php echo e((isset($total_point) && ($total_credit_earned)) ? number_format($total_point/$total_credit_earned, 2) : ''); ?></th>
							</tr>
							<?php endif; ?>

						</tbody>
					</table>
					
				</div>
			</div><!--/info body-->
		</div>

		<?php endif; ?>
	</div>

	<!--sidebar widget-->
	<div class="col-md-3">
		<?php echo $__env->make('pages.student.student-widget', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>